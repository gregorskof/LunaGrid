@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Zovanion LunaGrid - Building Windows application

echo.
echo  ======================================================
echo    ZOVANION LUNAGRID  ^|  Single EXE Windows Build
 echo  ======================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 goto :missingpython
    set "PYTHON=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating isolated Python environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :failed
)

 echo [2/3] Installing packaging dependencies...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :failed

 echo [3/3] Compiling the Windows GUI application...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name "LunaGrid" --icon "assets\lunagrid.ico" --add-data "assets\lunagrid.ico;assets" --add-data "assets\lunagrid-icon.png;assets" --noupx "main.py"
if errorlevel 1 goto :failed

echo.
echo  ======================================================
echo    SUCCESS: dist\LunaGrid.exe
 echo    One EXE. No console on app launch.
echo  ======================================================
echo.
explorer "%CD%\dist"
pause
exit /b 0

:missingpython
echo Python 3.11 or newer was not found.
echo Install Python from https://www.python.org/downloads/windows/
echo Enable "Add python.exe to PATH" and run this file again.
pause
exit /b 1

:failed
echo.
echo Build failed. Check the error shown above.
echo Ensure internet access for the first dependency install.
pause
exit /b 1
