"""Zovanion LunaGrid desktop entrypoint."""
from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path


def error_log(text):
    directory = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "LunaGrid"
    try:
        directory.mkdir(parents=True, exist_ok=True)
        with (directory / "error.log").open("a", encoding="utf-8") as out:
            out.write(text + "\n")
    except OSError:
        pass


def main():
    from PySide6.QtWidgets import QApplication, QMessageBox
    from PySide6.QtGui import QIcon
    from PySide6.QtCore import QElapsedTimer, QTimer
    from splash import build_splash

    app = QApplication(sys.argv)
    app.setApplicationName("LunaGrid")
    app.setOrganizationName("Zovanion")
    icon_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    icon_path = icon_root / "assets" / "lunagrid.ico"
    if icon_path.is_file():
        app.setWindowIcon(QIcon(str(icon_path)))
    app.setStyle("Fusion")
    # Display the splash before loading the larger GUI module.
    launch_clock = QElapsedTimer()
    launch_clock.start()
    splash = build_splash(icon_root / "assets")
    splash.show()
    app.processEvents()

    def exception_hook(cls, value, tb):
        error_log("".join(traceback.format_exception(cls, value, tb)))
        QMessageBox.critical(None, "Zovanion LunaGrid encountered a problem",
                             f"An unexpected error occurred:\n{value}\n\nDetails were saved to the application error.log.")
    sys.excepthook = exception_hook
    from ui import MainWindow
    file_arg = next((a for a in sys.argv[1:] if not a.startswith("-") and Path(a).is_file()), None)
    window = MainWindow(file_arg)

    def reveal_window():
        # Start in true fullscreen as requested; F11 or Esc restores a normal
        # maximized Windows window with its title-bar controls.
        window.showFullScreen()
        splash.finish(window)
        window.raise_()
        window.activateWindow()
        if window._needs_recovery_prompt:
            # Do not allow the recovery dialog to appear behind the splash.
            QTimer.singleShot(250, window.offer_recovery)

    QTimer.singleShot(max(150, 900 - launch_clock.elapsed()), reveal_window)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
