"""Branded, fast Office-style launch splash; no web requests or external assets."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QRect, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QSplashScreen


def build_splash(assets_dir: Path) -> QSplashScreen:
    width, height = 760, 390
    splash_image = QPixmap(width, height)
    splash_image.fill(Qt.GlobalColor.transparent)
    painter = QPainter(splash_image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    outer = QPainterPath()
    outer.addRoundedRect(QRectF(1, 1, width - 2, height - 2), 16, 16)
    painter.fillPath(outer, QColor("#FFFFFF"))
    painter.save()
    painter.setClipPath(outer)
    sidebar = QLinearGradient(0, 0, 280, height)
    sidebar.setColorAt(0, QColor("#123B86"))
    sidebar.setColorAt(1, QColor("#2566D9"))
    painter.fillRect(QRect(0, 0, 280, height), sidebar)

    # Subtle grid texture on the blue panel, like the workbook itself.
    painter.setPen(QPen(QColor(255, 255, 255, 25), 1))
    for x in range(0, 280, 28):
        painter.drawLine(x, 0, x, height)
    for y in range(0, height, 28):
        painter.drawLine(0, y, 280, y)
    painter.restore()

    icon = QPixmap(str(assets_dir / "lunagrid-icon.png"))
    if not icon.isNull():
        painter.drawPixmap(QRect(77, 83, 125, 125), icon)
    else:
        painter.setPen(QColor("#FFFFFF"))
        painter.setFont(QFont("Segoe UI", 76, QFont.Weight.Bold))
        painter.drawText(QRect(60, 77, 160, 145), Qt.AlignmentFlag.AlignCenter, "▦")

    painter.setPen(QColor("#FFFFFF"))
    painter.setFont(QFont("Segoe UI", 15, QFont.Weight.DemiBold))
    painter.drawText(QRect(0, 224, 280, 30), Qt.AlignmentFlag.AlignCenter, "ZOVANION")
    painter.setFont(QFont("Segoe UI", 10, QFont.Weight.Normal))
    painter.drawText(QRect(0, 260, 280, 28), Qt.AlignmentFlag.AlignCenter, "LUNAGRID  •  1.2")

    painter.setPen(QColor("#263B59"))
    painter.setFont(QFont("Segoe UI", 12, QFont.Weight.DemiBold))
    painter.drawText(320, 105, "ZOVANION")
    painter.setPen(QColor("#2867DD"))
    painter.setFont(QFont("Segoe UI", 34, QFont.Weight.Bold))
    painter.drawText(316, 171, "LunaGrid")
    painter.setPen(QColor("#64758C"))
    painter.setFont(QFont("Segoe UI", 13))
    painter.drawText(320, 210, "Spreadsheets, simplified.")

    painter.setPen(QColor("#CDD8E8"))
    painter.drawLine(320, 256, 716, 256)
    painter.setPen(QColor("#60738F"))
    painter.setFont(QFont("Segoe UI", 11))
    painter.drawText(320, 301, "Preparing your workspace…")
    painter.setPen(QColor("#9AA9BC"))
    painter.setFont(QFont("Segoe UI", 9))
    painter.drawText(320, 354, "Private & offline  •  Zovanion software")
    painter.setPen(QPen(QColor("#D6E1EF"), 1))
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawPath(outer)
    painter.end()

    splash = QSplashScreen(splash_image, Qt.WindowType.WindowStaysOnTopHint)
    splash.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
    return splash
