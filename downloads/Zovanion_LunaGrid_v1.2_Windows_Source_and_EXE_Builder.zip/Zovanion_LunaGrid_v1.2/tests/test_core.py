from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import core
import pytest
from openpyxl import load_workbook


def test_native_roundtrip_formatting_and_multiple_sheets(tmp_path):
    b = core.Book()
    s = b.sheets[0]
    s.put(0, 0, "Client")
    s.put(0, 1, "Revenue")
    s.put(1, 0, "Alpha")
    s.put(1, 1, 3000.25)
    s.set_style(1, 1, {"bold": True, "fill": "#112233", "format": "currency"})
    s.widths["0"] = 183
    b.sheets.append(core.Sheet(name="Report"))
    b.sheets[1].put(3, 5, True)
    b.active = 1
    destination = tmp_path / "test.luma"
    core.save_native(b, str(destination))
    other = core.load_native(str(destination))
    assert other.to_dict() == b.to_dict()
    assert zipfile.is_zipfile(destination)


def test_xlsx_roundtrip_formula_like_text_and_formats(tmp_path):
    b = core.Book()
    s = b.sheets[0]
    s.put(0, 0, "Value")
    s.put(1, 0, "=2+2")
    s.put(2, 0, 15.7)
    s.set_style(2, 0, {"bold": True, "format": "currency", "fill": "#123456"})
    path = tmp_path / "test.xlsx"
    core.export_xlsx(b, str(path))
    x = load_workbook(path, data_only=False)
    assert x.active["A2"].data_type == "s"
    assert x.active["A2"].value == "=2+2"
    assert x.active["A3"].font.bold is True
    assert x.active["A3"].number_format.startswith('"€"')
    x.close()
    back = core.load_xlsx(str(path))
    assert back.sheets[0].get(2, 0) == 15.7
    assert back.sheets[0].get(1, 0) == "=2+2"


def test_insert_delete_rows_cols_shifts_styles_and_widths():
    s = core.Sheet(rows=4, cols=4)
    s.put(2, 2, "X")
    s.set_style(2, 2, {"bold": True})
    s.widths["2"] = 175
    s.insert_rows(1, 2)
    s.insert_cols(1)
    assert s.get(4, 3) == "X"
    assert s.style(4, 3)["bold"] is True
    assert s.widths["3"] == 175
    s.delete_rows(2, 2)
    s.delete_cols(2)
    assert s.get(2, 2) == "X"


def test_sort_keeps_entire_rows_together():
    s = core.Sheet(rows=4, cols=2)
    s.put(0, 0, "Name")
    s.put(0, 1, "Value")
    for row, name, val in [(1, "Zeta", 4), (2, "Alpha", 2), (3, "Gamma", 3)]:
        s.put(row, 0, name)
        s.put(row, 1, val)
        s.set_style(row, 0, {"text": "#123456"})
    s.sort_by(0)
    assert [(s.get(r, 0), s.get(r, 1)) for r in range(1, 4)] == [
        ("Alpha", 2), ("Gamma", 3), ("Zeta", 4)]
    assert s.style(1, 0)["text"] == "#123456"


def test_duplicates_and_group_summary():
    s = core.Sheet(rows=5, cols=2)
    for r, row in enumerate([("Group", "Sales"), ("A", 10), ("B", 12), ("A", 10), ("A", 5)]):
        for c, val in enumerate(row):
            s.put(r, c, val)
    assert s.remove_duplicates() == 1
    summary = s.group_summary(0, 1, "sum")
    assert summary.get(1, 0) == "A"
    assert summary.get(1, 1) == 15
    assert summary.get(2, 1) == 12


def test_csv_unicode_and_quotes(tmp_path):
    s = core.Sheet()
    s.put(0, 0, "Name")
    s.put(1, 0, 'Jože, "test"')
    s.put(1, 1, 15)
    dest = tmp_path / "sheet.csv"
    core.export_csv(s, str(dest))
    loaded = core.import_csv(str(dest))
    assert loaded.sheets[0].get(1, 0) == 'Jože, "test"'
    assert loaded.sheets[0].get(1, 1) == 15


def test_native_rejects_unknown_version_and_bad_dimensions(tmp_path):
    book = core.Book()
    raw = book.to_dict()
    raw["version"] = 300
    with pytest.raises(ValueError, match="version"):
        core.Book.from_dict(raw)
    raw["version"] = 1
    raw["sheets"][0]["rows"] = 500_000
    with pytest.raises(ValueError, match="dimensions"):
        core.Book.from_dict(raw)


def test_parse_preserves_zip_codes_and_equations():
    assert core.parse_input("00123") == "00123"
    assert core.parse_input("=SUM(B3:B9)") == "=SUM(B3:B9)"
    assert core.parse_input("12.52") == 12.52
    assert core.parse_input("hello") == "hello"


def test_descending_sort_keeps_empty_rows_at_end():
    sheet = core.Sheet(rows=5, cols=2)
    sheet.put(0, 0, "Revenue")
    sheet.put(1, 0, 11)
    sheet.put(2, 0, 30)
    sheet.put(3, 0, 20)
    sheet.sort_by(0, reverse=True)
    assert [sheet.get(r, 0) for r in range(1, 5)] == [30, 20, 11, None]


def test_csv_formula_injection_is_escaped(tmp_path):
    sheet = core.Sheet()
    sheet.put(0, 0, "Description")
    sheet.put(1, 0, "=HYPERLINK(\"https://example.org\")")
    path = tmp_path / "safe.csv"
    core.export_csv(sheet, str(path))
    assert "'=HYPERLINK" in path.read_text(encoding="utf-8-sig")
