"""Regression tests for the new one-click workbook actions (no Qt needed)."""
import pytest

from core import (MAX_ROWS, Sheet, fill_number_series, format_header_row,
                  highlight_duplicate_values, split_text_column, transform_text_cells)


def test_numeric_series_and_overflow_guard():
    sheet = Sheet(rows=2, cols=2)
    fill_number_series(sheet, 1, 0, 4, 1.5, 0.5)
    assert [sheet.get(r, 0) for r in range(1, 5)] == [1.5, 2, 2.5, 3]
    assert sheet.rows == 5
    with pytest.raises(ValueError):
        fill_number_series(sheet, MAX_ROWS - 1, 0, 3, 1, 1)
    with pytest.raises(ValueError):
        fill_number_series(sheet, 0, 0, 2, float("inf"), 1)


def test_split_column_preserves_neighbor_cells_and_styles():
    sheet = Sheet(rows=5, cols=3)
    sheet.put(0, 0, "First,Last,City")
    sheet.put(1, 0, "Ana,Kovač,Ljubljana")
    sheet.put(1, 1, "Adjacent data")
    sheet.set_style(1, 1, {"bold": True})
    assert split_text_column(sheet, 0, ",") == 2
    assert [sheet.get(1, c) for c in range(4)] == ["Ana", "Kovač", "Ljubljana", "Adjacent data"]
    assert sheet.style(1, 3)["bold"] is True
    assert sheet.get(0, 2) == "City"
    assert split_text_column(sheet, 0, "|") == 0


def test_split_column_limits_columns():
    sheet = Sheet(rows=2, cols=500)
    sheet.put(1, 0, "A;B")
    with pytest.raises(ValueError):
        split_text_column(sheet, 0, ";")
    assert sheet.get(1, 0) == "A;B"  # No partial mutation on failure.


def test_text_transform_only_requested_cells():
    sheet = Sheet(rows=4)
    sheet.put(1, 0, "  hello World  ")
    sheet.put(2, 0, "UNCHANGED")
    assert transform_text_cells(sheet, [(1, 0)], "Trim spaces") == 1
    assert transform_text_cells(sheet, [(1, 0)], "Title Case") == 1
    assert sheet.get(1, 0) == "Hello World"
    assert sheet.get(2, 0) == "UNCHANGED"
    with pytest.raises(ValueError):
        transform_text_cells(sheet, [(1, 0)], "eval")


def test_duplicate_highlighting_ignores_heading_and_blanks():
    sheet = Sheet(rows=7)
    sheet.put(0, 0, "Group")
    sheet.put(1, 0, "Alpha")
    sheet.put(2, 0, "beta")
    sheet.put(3, 0, " alpha ")
    sheet.put(4, 0, "Beta")
    assert highlight_duplicate_values(sheet, 0) == 4
    assert sheet.style(1, 0)["fill"] == "#FFF0C2"
    assert sheet.style(3, 0)["fill"] == "#FFF0C2"
    assert not sheet.style(0, 0)


def test_header_style_only_occupied_header_cells():
    sheet = Sheet(rows=5, cols=10)
    sheet.put(0, 0, "Name")
    sheet.put(0, 2, "Value")
    assert format_header_row(sheet) == 2
    assert sheet.style(0, 0)["bold"] is True
    assert sheet.style(0, 2)["text"] == "#FFFFFF"
    assert not sheet.style(0, 1)
