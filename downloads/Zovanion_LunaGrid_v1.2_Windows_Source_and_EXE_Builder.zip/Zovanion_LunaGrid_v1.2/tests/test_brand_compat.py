import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import core


def test_previous_lumagrid_file_still_opens(tmp_path):
    # An actual file from the former app stores app=LumaGrid.
    source = Path(__file__).resolve().parents[1] / 'example.luma'
    assert source.is_file()
    workbook = core.load_native(source)
    assert workbook.sheets
    # It can be resaved with the new application name without changing .luma.
    path = tmp_path / 'upgraded.luma'
    core.save_native(workbook, path)
    assert core.load_native(path).to_dict()['app'] == 'Zovanion LunaGrid'


def test_legacy_identifiers_are_accepted():
    book = core.Book().to_dict()
    for legacy in ['LumaGrid', 'LunaGrid', 'Zovanion LunaGrid']:
        variant = dict(book, app=legacy)
        assert core.Book.from_dict(variant).sheets


def test_rejects_unknown_identifiers():
    book = core.Book().to_dict()
    book['app'] = 'Unrelated App'
    try:
        core.Book.from_dict(book)
    except ValueError:
        return
    raise AssertionError('Unrelated documents must be rejected')
