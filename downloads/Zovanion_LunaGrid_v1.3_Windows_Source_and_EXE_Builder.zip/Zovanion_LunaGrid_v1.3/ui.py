"""Point-and-click PySide6 desktop interface for Zovanion LunaGrid."""
from __future__ import annotations

import csv
from datetime import date
import io
import math
import os
import re
import sys
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QObject, QPoint, QRectF, Qt, QSortFilterProxyModel, QSettings, QTimer, Signal
from PySide6.QtGui import (QAction, QBrush, QColor, QFont, QIcon, QKeySequence, QLinearGradient, QPainter,
                           QPainterPath, QPen, QRadialGradient, QShortcut, QUndoCommand, QUndoStack)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QColorDialog, QComboBox, QDialog,
                               QFileDialog, QFormLayout, QFrame, QGraphicsDropShadowEffect, QGridLayout, QDoubleSpinBox,
                               QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QMainWindow,
                               QMenu, QMessageBox, QPushButton, QSizePolicy, QSpinBox, QStackedWidget,
                               QStyledItemDelegate,
                               QTabBar, QTabWidget, QTableView, QTextEdit, QVBoxLayout, QWidget)

import core

# LunaGrid theme system. The app starts in light mode; preferences use QSettings.
# The UI is intentionally crisp and restrained, inspired by modern desktop data tools.
from string import Template

THEMES = {
    "light": {
        "app": "#F3F6FB", "app_bottom": "#EDF3F9", "panel": "#FFFFFF",
        "panel_high": "#F8FAFF", "border": "#DCE4F0", "line": "#E6ECF4",
        "text": "#233348", "muted": "#60748E", "subtle": "#8292A8",
        "accent": "#326CE5", "accent_hover": "#245AC8", "accent_pale": "#EAF1FF",
        "accent_text": "#FFFFFF", "button": "#FFFFFF", "button_hover": "#EDF4FF",
        "grid": "#FFFFFF", "alternate": "#F7F9FD", "head": "#EEF3F9",
        "head_hover": "#DCE8FA", "selection": "#DCEAFF", "selection_text": "#163D85",
        "input": "#FFFFFF", "scroll": "#E7ECF4", "scroll_handle": "#B8C6D8",
        "danger": "#B83A50", "menu_hover": "#EAF1FF", "brand": "#326CE5",
    },
    "dark": {
        "app": "#101827", "app_bottom": "#141E2E", "panel": "#1A2637",
        "panel_high": "#1C2A3F", "border": "#35445A", "line": "#2D3B50",
        "text": "#E8EFFA", "muted": "#A6B7CF", "subtle": "#879BB8",
        "accent": "#7CB3FF", "accent_hover": "#A1C9FF", "accent_pale": "#263F62",
        "accent_text": "#101E33", "button": "#253449", "button_hover": "#304968",
        "grid": "#172234", "alternate": "#1D2B40", "head": "#25364D",
        "head_hover": "#324A68", "selection": "#345B91", "selection_text": "#FFFFFF",
        "input": "#243348", "scroll": "#162233", "scroll_handle": "#49637F",
        "danger": "#FF9AA8", "menu_hover": "#314B6C", "brand": "#8BBEFF",
    },
}

STYLE = Template(r"""
* { font-family: 'Segoe UI', 'Arial', sans-serif; font-size: 12px; color: $text; }
QWidget { background: transparent; }
QLabel#appIcon { font-size: 25px; color: $accent; font-weight: 800; }
QLabel#brand { font-size: 22px; font-weight: 800; color: $text; }
QLabel#eyebrow { color: $muted; font-weight: 700; font-size: 10px; }
QLabel#hero { font-size: 20px; font-weight: 750; color: $text; }
QLabel#subhero { color: $muted; font-size: 12px; }
QLabel#caption { color: $subtle; font-size: 11px; }
QLabel#stat { color: $text; font-size: 13px; font-weight: 700; }
QPushButton { color: $text; border: 1px solid $border; border-radius: 8px;
              background: $button; padding: 5px 12px; font-weight: 600; }
QPushButton:hover { background: $button_hover; border-color: $accent; }
QPushButton:pressed { background: $accent_pale; }
QPushButton:disabled { color: $subtle; }
QPushButton#primary { background: $accent; color: $accent_text; font-weight: 700; border: 1px solid $accent; }
QPushButton#primary:hover { background: $accent_hover; border-color: $accent_hover; }
QPushButton#quiet { background: $button; border-color: $border; }
QPushButton#danger { color: $danger; }
QPushButton#tool { background: $button; min-height: 29px; min-width: 85px; padding: 3px 11px; }
QPushButton#square { min-width: 30px; max-width: 34px; min-height: 28px; padding: 1px; font-size: 17px; }
QTabWidget::pane { border: none; background: transparent; }
QTabBar::tab { background: transparent; color: $muted; border: 1px solid transparent;
               border-radius: 7px; padding: 5px 14px; margin-right: 4px; font-weight: 600; }
QTabBar::tab:selected { background: $accent_pale; color: $accent; border-color: $border; }
QTabBar::tab:hover { background: $button_hover; }
QTableView { background: $grid; alternate-background-color: $alternate; border: 1px solid $border;
             border-radius: 7px; gridline-color: $line; color: $text;
             selection-background-color: $selection; selection-color: $selection_text; font-size: 13px; }
QTableView::item { padding: 1px 8px; }
QTableView::item:selected { border: 1px solid $accent; }
QTableCornerButton::section { background: $head; border: 1px solid $line; }
QHeaderView::section { background: $head; color: $muted; padding: 7px;
                       border: none; border-right: 1px solid $line; border-bottom: 1px solid $line;
                       font-weight: 700; }
QHeaderView::section:hover { background: $head_hover; }
QLineEdit, QComboBox, QSpinBox, QTextEdit { background: $input; color: $text;
             padding: 7px 10px; border: 1px solid $border; border-radius: 7px;
             selection-background-color: $accent_pale; selection-color: $text; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border: 1px solid $accent; }
/* Grid editor uses its own compact text geometry, never the dialog-input padding. */
QTableView QLineEdit { background: $input; color: $text; padding: 0px 5px;
                       border: 2px solid $accent; border-radius: 0px; font-size: 13px; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView { background: $panel; color: $text; border: 1px solid $border;
                               selection-background-color: $accent_pale; padding: 4px; outline: none; }
QMenu { background: $panel; border: 1px solid $border; border-radius: 8px; padding: 5px; }
QMenu::item { padding: 8px 22px; border-radius: 5px; }
QMenu::item:selected { background: $menu_hover; }
QDialog, QMessageBox, QInputDialog, QFileDialog, QColorDialog { background: $panel; color: $text; }
QCheckBox { color: $text; padding: 3px; }
QCheckBox::indicator { width: 16px; height: 16px; }
QScrollBar:vertical { width: 11px; background: $scroll; border: none; }
QScrollBar:horizontal { height: 11px; background: $scroll; border: none; }
QScrollBar::handle { background: $scroll_handle; border-radius: 5px; min-height: 24px; min-width: 24px; }
QScrollBar::handle:hover { background: $accent; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0px; width: 0px; }
QToolTip { color: $text; background: $panel; border: 1px solid $border; padding: 6px; }
""")


def theme_stylesheet(theme: str) -> str:
    return STYLE.substitute(THEMES[theme])


class AmbientSurface(QWidget):
    """A low-contrast application background, not a translucent glass effect."""
    def __init__(self, theme="light", parent=None):
        super().__init__(parent)
        self.theme = theme

    def set_theme(self, theme):
        self.theme = theme
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        palette = THEMES[self.theme]
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(palette["app"]))
        gradient.setColorAt(1, QColor(palette["app_bottom"]))
        painter.fillRect(self.rect(), gradient)
        painter.end()


class GlassPanel(QWidget):
    """Subtle solid desktop panel; retained class name for workbook UI compatibility."""
    def __init__(self, parent=None, radius=12, bright=False, theme="light"):
        super().__init__(parent)
        self._radius = radius
        self._bright = bright
        self.theme = theme

    def set_theme(self, theme):
        self.theme = theme
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        color = THEMES[self.theme]
        path = QPainterPath()
        path.addRoundedRect(rect, self._radius, self._radius)
        painter.fillPath(path, QColor(color["panel_high"] if self._bright else color["panel"]))
        painter.setPen(QPen(QColor(color["border"]), 1.0))
        painter.drawPath(path)
        painter.end()


class SheetModel(QAbstractTableModel):
    def __init__(self, sheet: core.Sheet, stack: QUndoStack, dirty: Callable, parent=None):
        super().__init__(parent)
        self.sheet = sheet
        self.stack = stack
        self.dirty = dirty
        self.theme = "light"

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self.sheet.rows

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self.sheet.cols

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            return core.column_label(section) if orientation == Qt.Orientation.Horizontal else str(section + 1)
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return Qt.AlignmentFlag.AlignCenter
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        r, c = index.row(), index.column()
        value = self.sheet.get(r, c)
        styling = self.sheet.style(r, c)
        if role == Qt.ItemDataRole.EditRole:
            return "" if value is None else str(value)
        if role == Qt.ItemDataRole.DisplayRole:
            if value is None:
                return ""
            fmt = styling.get("format", "general")
            n = core.number(value)
            if n is not None:
                if fmt == "currency":
                    return f"€ {n:,.2f}"
                if fmt == "percent":
                    return f"{n * 100:,.2f}%"
                if fmt == "integer":
                    return f"{n:,.0f}"
                if fmt == "number":
                    return f"{n:,.2f}"
            return str(value)
        if role == Qt.ItemDataRole.BackgroundRole:
            fill = styling.get("fill")
            if fill:
                return QBrush(QColor(fill))
            if self.sheet.banded and r % 2 == 1:
                return QBrush(QColor(THEMES[self.theme]["alternate"]))
        if role == Qt.ItemDataRole.ForegroundRole:
            return QBrush(QColor(styling.get("text", THEMES[self.theme]["text"])))
        if role == Qt.ItemDataRole.FontRole and styling.get("bold"):
            font = QFont("Segoe UI", 10)
            font.setBold(True)
            return font
        if role == Qt.ItemDataRole.TextAlignmentRole:
            alignment = styling.get("align")
            if alignment == "center":
                return Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignHCenter
            if alignment == "right" or (alignment is None and isinstance(value, (int, float))):
                return Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight
            return Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
        return None

    def flags(self, index):
        if not index.isValid():
            return Qt.ItemFlag.NoItemFlags
        return Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEditable

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if not index.isValid() or role != Qt.ItemDataRole.EditRole:
            return False
        new = core.parse_input(value)
        old = self.sheet.get(index.row(), index.column())
        if old == new:
            return False
        self.stack.push(CellCommand(self, index.row(), index.column(), old, new))
        return True

    def raw_set(self, r, c, value):
        self.sheet.put(r, c, value)
        index = self.index(r, c)
        self.dataChanged.emit(index, index)
        self.dirty()

    def refresh(self):
        self.beginResetModel()
        self.endResetModel()
        self.dirty()


class ColumnFilter(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.column = -1
        self.search = ""

    def filterAcceptsRow(self, source_row, source_parent):
        if self.column == -1 or not self.search:
            return True
        # The header is always visible.
        if source_row == 0:
            return True
        model = self.sourceModel()
        return self.search in str(model.sheet.get(source_row, self.column) or "").casefold()

    def set_column_filter(self, column, text):
        self.column = column
        self.search = text.casefold().strip()
        self.invalidateFilter()


class CellCommand(QUndoCommand):
    def __init__(self, model, row, col, before, after):
        super().__init__(f"Edit {core.column_label(col)}{row + 1}")
        self.model, self.row, self.col = model, row, col
        self.before, self.after = before, after

    def undo(self):
        self.model.raw_set(self.row, self.col, self.before)

    def redo(self):
        self.model.raw_set(self.row, self.col, self.after)


class BulkCommand(QUndoCommand):
    def __init__(self, model, description, before, after):
        super().__init__(description)
        self.model, self.before, self.after = model, before, after

    def undo(self):
        self.model.sheet.restore(self.before)
        self.model.refresh()

    def redo(self):
        self.model.sheet.restore(self.after)
        self.model.refresh()


class SheetCellDelegate(QStyledItemDelegate):
    """Use a legible, full-height edit control inside every spreadsheet cell."""
    def __init__(self, theme="light", parent=None):
        super().__init__(parent)
        self.theme = theme

    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setFrame(False)
        editor.setFont(QFont("Segoe UI", 11))
        editor.setTextMargins(4, 0, 4, 0)
        color = THEMES[self.theme]
        editor.setStyleSheet(
            f"QLineEdit {{ font-family: 'Segoe UI'; font-size: 13px; "
            f"color: {color['text']}; background: {color['input']}; "
            f"padding: 0px 4px; margin: 0px; border: 2px solid {color['accent']}; "
            f"border-radius: 0px; }}"
        )
        return editor

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect.adjusted(1, 1, -1, -1))


class GridView(QTableView):
    copyRequested = Signal()
    pasteRequested = Signal()
    clearRequested = Signal()

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copyRequested.emit()
        elif event.matches(QKeySequence.StandardKey.Paste):
            self.pasteRequested.emit()
        elif event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.clearRequested.emit()
        else:
            super().keyPressEvent(event)


class ChartCanvas(QWidget):
    def __init__(self, parent=None, theme="light"):
        super().__init__(parent)
        self.theme = theme
        self.kind = "Bar"
        self.points: list[tuple[str, float]] = []
        self.setMinimumSize(620, 350)

    def set_chart(self, kind, points):
        self.kind, self.points = kind, points
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        region = QRectF(self.rect()).adjusted(8, 8, -8, -8)
        colors = THEMES[self.theme]
        p.setPen(QPen(QColor(colors["border"]), 1))
        p.setBrush(QColor(colors["panel_high"]))
        p.drawRoundedRect(region, 15, 15)
        if not self.points:
            p.setPen(QColor(colors["muted"]))
            p.drawText(region, Qt.AlignmentFlag.AlignCenter, "No numeric data to visualize")
            return
        points = self.points[:16]
        palette = ["#8BD8FC", "#B7A2FF", "#75DCC5", "#FFC795", "#E68BBF", "#83A9FF"]
        if self.kind == "Pie":
            positives = [(name, max(0, value)) for name, value in points if value > 0]
            total = sum(v for _, v in positives)
            if total <= 0:
                p.setPen(QColor(colors["muted"]))
                p.drawText(region, Qt.AlignmentFlag.AlignCenter, "Pie charts require positive values")
                return
            pie = QRectF(region.left() + 55, region.top() + 40, 250, 250)
            offset = 0
            for i, (_, value) in enumerate(positives):
                p.setPen(QPen(QColor(colors["border"]), 2))
                p.setBrush(QColor(palette[i % len(palette)]))
                extent = int(value / total * 5760)
                p.drawPie(pie, offset, extent)
                offset += extent
            for i, (name, value) in enumerate(positives[:10]):
                y = region.top() + 35 + i * 27
                p.fillRect(QRectF(region.left() + 345, y, 12, 12), QColor(palette[i % len(palette)]))
                p.setPen(QColor(colors["text"]))
                p.drawText(QRectF(region.left() + 365, y - 4, region.width() - 380, 25),
                           Qt.AlignmentFlag.AlignVCenter, f"{name[:18]}  {value / total:.0%}")
            return
        plot = region.adjusted(58, 42, -28, -58)
        bottom, top = min(0, *(value for _, value in points)), max(0, *(value for _, value in points))
        if bottom == top:
            top = bottom + 1
        p.setPen(QPen(QColor(colors["line"]), 1))
        for i in range(5):
            y = plot.bottom() - i * plot.height() / 4
            p.drawLine(QPoint(int(plot.left()), int(y)), QPoint(int(plot.right()), int(y)))
            value = bottom + i * (top - bottom) / 4
            p.setPen(QColor(colors["muted"]))
            p.drawText(QRectF(region.left() + 2, y - 11, 51, 20), Qt.AlignmentFlag.AlignRight,
                       f"{value:,.1f}" if abs(value) < 10000 else f"{value / 1000:.0f}k")
            p.setPen(QPen(QColor(colors["line"]), 1))
        slot = plot.width() / max(len(points), 1)
        zero_y = plot.bottom() - ((0 - bottom) / (top - bottom)) * plot.height()
        line_points = []
        for i, (name, value) in enumerate(points):
            x = plot.left() + slot * (i + .5)
            y = plot.bottom() - ((value - bottom) / (top - bottom)) * plot.height()
            if self.kind == "Bar":
                w = min(43, slot * .68)
                bar = QRectF(x - w / 2, min(y, zero_y), w, max(abs(zero_y - y), 1.5))
                fill = QLinearGradient(bar.topLeft(), bar.bottomLeft())
                fill.setColorAt(0, QColor(palette[i % len(palette)]))
                fill.setColorAt(1, QColor("#5575BB"))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(fill)
                p.drawRoundedRect(bar, min(6, w / 4), min(6, w / 4))
            else:
                line_points.append(QPoint(int(x), int(y)))
            p.setPen(QColor(colors["muted"]))
            name = name[:9] + ("…" if len(name) > 9 else "")
            p.drawText(QRectF(x - slot * .48, plot.bottom() + 9, slot * .96, 35),
                       Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, name)
        if self.kind == "Area" and line_points:
            area_path = QPainterPath()
            area_path.moveTo(float(line_points[0].x()), float(zero_y))
            for pt in line_points:
                area_path.lineTo(float(pt.x()), float(pt.y()))
            area_path.lineTo(float(line_points[-1].x()), float(zero_y))
            area_path.closeSubpath()
            gradient = QLinearGradient(0, plot.top(), 0, plot.bottom())
            gradient.setColorAt(0, QColor(82, 132, 242, 165))
            gradient.setColorAt(1, QColor(82, 132, 242, 25))
            p.fillPath(area_path, gradient)
        if self.kind in ("Line", "Area") and line_points:
            p.setPen(QPen(QColor("#5284F2"), 3))
            for left, right in zip(line_points, line_points[1:]):
                p.drawLine(left, right)
            p.setPen(QPen(QColor(colors["panel"]), 1))
            p.setBrush(QColor("#8DD8FF"))
            for pt in line_points:
                p.drawEllipse(pt, 4, 4)
        p.end()


class ChartDialog(QDialog):
    def __init__(self, sheet: core.Sheet, parent=None, theme="light"):
        super().__init__(parent)
        self.sheet = sheet
        self.setWindowTitle("Zovanion LunaGrid • Visualize data")
        self.resize(760, 565)
        root = QVBoxLayout(self)
        root.setSpacing(12)
        heading = QLabel("Instant insights")
        heading.setObjectName("hero")
        root.addWidget(heading)
        row = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItems(["Bar", "Line", "Area", "Pie"])
        self.category = QComboBox()
        self.value_selector = QComboBox()
        for col in range(sheet.cols):
            title = sheet.get(0, col)
            name = f"{core.column_label(col)} · {str(title)[:30] if title is not None else 'Column'}"
            self.category.addItem(name, col)
            self.value_selector.addItem(name, col)
        numeric_counts = [sum(1 for r in range(1, min(sheet.rows, 2000)) if core.number(sheet.get(r, c)) is not None)
                          for c in range(sheet.cols)]
        preferred = max(range(sheet.cols), key=lambda c: (numeric_counts[c], c > 0))
        self.value_selector.setCurrentIndex(preferred)
        for label, widget in [("CHART", self.kind), ("LABELS", self.category), ("VALUES", self.value_selector)]:
            row.addWidget(QLabel(label))
            row.addWidget(widget, 1)
        root.addLayout(row)
        self.canvas = ChartCanvas(theme=theme)
        root.addWidget(self.canvas, 1)
        self.foot = QLabel("Uses the first 16 categories, grouped by label.")
        self.foot.setObjectName("caption")
        root.addWidget(self.foot)
        buttons = QHBoxLayout()
        buttons.addStretch()
        save = make_button("Save PNG", self.save_png, "primary")
        close = make_button("Close", self.accept, "quiet")
        buttons.addWidget(close)
        buttons.addWidget(save)
        root.addLayout(buttons)
        for combo in (self.kind, self.category, self.value_selector):
            combo.currentIndexChanged.connect(self.redraw)
        self.redraw()

    def redraw(self):
        category_col, metric_col = self.category.currentData(), self.value_selector.currentData()
        groups: dict[str, float] = defaultdict(float)
        for row in range(1, self.sheet.rows):
            name = self.sheet.get(row, category_col)
            value = core.number(self.sheet.get(row, metric_col))
            if name is not None and value is not None:
                groups[str(name)] += value
        self.canvas.set_chart(self.kind.currentText(), list(groups.items())[:16])
        self.foot.setText(f"{len(groups)} categories available · Showing up to 16 · Sum of matching values")

    def save_png(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save chart image", "LunaGrid-chart.png", "PNG image (*.png)")
        if path and not self.canvas.grab().save(path):
            QMessageBox.warning(self, "Could not save", "Unable to save the chart image.")


def make_button(label: str, callback: Callable, style: str = "tool", tip: str = "") -> QPushButton:
    btn = QPushButton(label)
    btn.setObjectName(style)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.clicked.connect(callback)
    if tip:
        btn.setToolTip(tip)
    return btn


def native_file_association(exe_path: str):
    if sys.platform != "win32":
        raise OSError("File association is available only on Windows")
    import ctypes
    import winreg
    base = r"Software\Classes"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\.luma") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "LunaGrid.Document")
        winreg.SetValueEx(k, "Content Type", 0, winreg.REG_SZ, "application/x-lunagrid")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\LunaGrid.Document") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "Zovanion LunaGrid workbook")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\LunaGrid.Document\DefaultIcon") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, f'"{exe_path}",0')
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\LunaGrid.Document\shell\open\command") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, f'"{exe_path}" "%1"')
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)


class MainWindow(QMainWindow):
    def __init__(self, initial_path: str | None = None):
        super().__init__()
        self.book = core.Book()
        self.path: str | None = None
        self.dirty = False
        self.undo_stack = QUndoStack(self)
        self.recovery_path = str(Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "LunaGrid" / "recovery.luma") if sys.platform == "win32" else str(Path.home() / ".lunagrid" / "recovery.luma")
        self.setMinimumSize(1030, 690)
        self.resize(1490, 940)
        self.setWindowTitle("Zovanion LunaGrid")
        self.setAcceptDrops(True)
        self.preferences = QSettings("Zovanion", "LunaGrid")
        saved_theme = self.preferences.value("appearance/theme", "light")
        self.theme = saved_theme if saved_theme in THEMES else "light"
        QApplication.instance().setStyleSheet(theme_stylesheet(self.theme))
        # The request explicitly includes opening native workbooks by double-click.
        # Register the file type for the current Windows user on packaged launches.
        if sys.platform == "win32" and getattr(sys, "frozen", False):
            try:
                native_file_association(sys.executable)
            except OSError:
                pass  # User can retry through the file menu.
        self._build_ui()
        self._bind_shortcuts()
        self._init_model()
        self.auto_timer = QTimer(self)
        self.auto_timer.timeout.connect(self.autosave)
        self.auto_timer.start(45_000)
        self._needs_recovery_prompt = not bool(initial_path)
        if initial_path:
            self.open_path(initial_path)

    def update_brand_label(self):
        accent = THEMES[self.theme]["brand"]
        self.brand_label.setText(
            f"<span style='font-weight:750'>ZOVANION</span> "
            f"<span style='color:{accent};font-weight:800'>LUNAGRID</span>"
        )

    def update_theme_button(self):
        self.theme_button.setText("☾  Dark mode" if self.theme == "light" else "☀  Light mode")

    def toggle_theme(self):
        self.set_theme("dark" if self.theme == "light" else "light")

    def set_theme(self, theme):
        if theme not in THEMES:
            raise ValueError("Unknown theme")
        self.theme = theme
        self.preferences.setValue("appearance/theme", theme)
        QApplication.instance().setStyleSheet(theme_stylesheet(theme))
        self.update_brand_label()
        self.update_theme_button()
        for panel in (self.canvas, self.hero_panel, self.ribbon_panel, self.sheet_panel):
            panel.set_theme(theme)
        self.cell_delegate.theme = theme
        self.model.theme = theme
        self.grid.viewport().update()
        self.grid.horizontalHeader().viewport().update()
        self.grid.verticalHeader().viewport().update()

    def _build_ui(self):
        canvas = AmbientSurface(theme=self.theme)
        self.canvas = canvas
        self.setCentralWidget(canvas)
        main = QVBoxLayout(canvas)
        main.setContentsMargins(18, 11, 18, 10)
        main.setSpacing(9)
        top = QHBoxLayout()
        icon = QLabel("▦")
        icon.setObjectName("appIcon")
        top.addWidget(icon)
        branding = QVBoxLayout()
        branding.setSpacing(0)
        brand = QLabel()
        self.brand_label = brand
        self.update_brand_label()
        brand.setTextFormat(Qt.TextFormat.RichText)
        brand.setObjectName("brand")
        tagline = QLabel("SPREADSHEETS, SIMPLIFIED")
        tagline.setObjectName("eyebrow")
        branding.addWidget(brand)
        branding.addWidget(tagline)
        top.addLayout(branding)
        top.addSpacing(16)
        mode = QLabel("  ●  PRIVATE & OFFLINE  ")
        mode.setObjectName("eyebrow")
        top.addWidget(mode)
        top.addStretch()
        self.file_label = QLabel("Untitled workbook")
        self.file_label.setObjectName("caption")
        top.addWidget(self.file_label)
        top.addSpacing(11)
        self.theme_button = make_button("", self.toggle_theme, "quiet", "Switch between light and dark mode")
        self.update_theme_button()
        top.addWidget(self.theme_button)
        self.screen_button = make_button("⛶ Full screen", self.toggle_fullscreen, "quiet", "Toggle borderless fullscreen (F11); starts maximized")
        top.addWidget(self.screen_button)
        for label, fn, kind in [("New", self.new_book, "quiet"), ("Open", self.choose_open, "quiet"),
                                ("Save", self.save, "primary"), ("Excel ↗", self.export_excel, "quiet")]:
            top.addWidget(make_button(label, fn, kind))
        menu = make_button("⋯", self.show_file_menu, "square", "More file actions")
        self.more_button = menu
        top.addWidget(menu)
        main.addLayout(top)

        hero = GlassPanel(bright=True, theme=self.theme)
        self.hero_panel = hero
        h = QHBoxLayout(hero)
        h.setContentsMargins(20, 10, 20, 10)
        headline = QVBoxLayout()
        headline.setSpacing(3)
        t = QLabel("Your data, beautifully simple.")
        t.setObjectName("hero")
        sub = QLabel("Edit freely. Analyze with a click. Export whenever you want.")
        sub.setObjectName("subhero")
        headline.addWidget(t)
        headline.addWidget(sub)
        h.addLayout(headline)
        h.addStretch(1)
        self.stat_cells = QLabel("0 filled cells")
        self.stat_cells.setObjectName("stat")
        self.stat_sheets = QLabel("1 sheet")
        self.stat_sheets.setObjectName("stat")
        for title, label in [("DATA", self.stat_cells), ("WORKBOOK", self.stat_sheets)]:
            segment = QVBoxLayout()
            segment.setSpacing(3)
            caption = QLabel(title)
            caption.setObjectName("eyebrow")
            segment.addWidget(caption)
            segment.addWidget(label)
            h.addLayout(segment)
            h.addSpacing(25)
        main.addWidget(hero)

        ribbon = GlassPanel(radius=12, theme=self.theme)
        self.ribbon_panel = ribbon
        ribbon_layout = QVBoxLayout(ribbon)
        ribbon_layout.setContentsMargins(11, 5, 11, 5)
        ribbon_layout.setSpacing(3)
        self.tools = QTabWidget()
        self.tools.setDocumentMode(True)
        self.tools.addTab(self._home_tools(), "✦  Home")
        self.tools.addTab(self._data_tools(), "▦  Data")
        self.tools.addTab(self._insert_tools(), "＋  Insert")
        self.tools.addTab(self._insights_tools(), "◉  Insights")
        self.tools.addTab(self._smart_tools(), "▧  More tools")
        self.tools.addTab(self._view_tools(), "◫  View")
        ribbon_layout.addWidget(self.tools)
        main.addWidget(ribbon)

        sheet_panel = GlassPanel(radius=12, theme=self.theme)
        self.sheet_panel = sheet_panel
        sheet_layout = QVBoxLayout(sheet_panel)
        sheet_layout.setContentsMargins(12, 9, 12, 9)
        sheet_layout.setSpacing(8)
        bar = QHBoxLayout()
        label = QLabel("WORKSHEETS")
        label.setObjectName("eyebrow")
        bar.addWidget(label)
        bar.addSpacing(12)
        self.tabs = QTabBar()
        self.tabs.setExpanding(False)
        self.tabs.setTabsClosable(False)
        self.tabs.setDrawBase(False)
        self.tabs.currentChanged.connect(self.switch_sheet)
        self.tabs.tabBarDoubleClicked.connect(self.rename_sheet)
        bar.addWidget(self.tabs)
        bar.addWidget(make_button("+", self.add_sheet, "square", "Add worksheet"))
        bar.addStretch()
        self.filter_badge = QLabel("All rows visible")
        self.filter_badge.setObjectName("caption")
        bar.addWidget(self.filter_badge)
        bar.addWidget(make_button("Clear filter", self.clear_filter, "quiet"))
        sheet_layout.addLayout(bar)
        self.grid = GridView()
        self.grid.setWordWrap(False)
        self.grid.setAlternatingRowColors(True)
        self.grid.setShowGrid(True)
        self.grid.setSortingEnabled(False)
        self.grid.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.grid.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.grid.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked |
                                  QAbstractItemView.EditTrigger.EditKeyPressed |
                                  QAbstractItemView.EditTrigger.AnyKeyPressed)
        self.grid.horizontalHeader().setDefaultSectionSize(155)
        self.grid.horizontalHeader().setMinimumSectionSize(60)
        self.grid.horizontalHeader().setSectionsMovable(False)
        self.grid.verticalHeader().setDefaultSectionSize(38)
        self.grid.verticalHeader().setMinimumWidth(46)
        self.grid.setFont(QFont("Segoe UI", 10))
        self.cell_delegate = SheetCellDelegate(self.theme, self.grid)
        self.grid.setItemDelegate(self.cell_delegate)
        self.grid.setCornerButtonEnabled(True)
        self.grid.copyRequested.connect(self.copy_cells)
        self.grid.pasteRequested.connect(self.paste_cells)
        self.grid.clearRequested.connect(self.clear_cells)
        self.grid.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid.customContextMenuRequested.connect(self.grid_menu)
        self._restoring_columns = False
        self.grid.horizontalHeader().sectionResized.connect(self.remember_width)
        sheet_layout.addWidget(self.grid, 1)
        main.addWidget(sheet_panel, 1)

        bottom = QHBoxLayout()
        self.status = QLabel("Ready · Select cells to see instant statistics")
        self.status.setObjectName("caption")
        bottom.addWidget(self.status)
        bottom.addStretch()
        self.selection_stats = QLabel("SUM  —    AVERAGE  —    COUNT  —")
        self.selection_stats.setObjectName("stat")
        bottom.addWidget(self.selection_stats)
        main.addLayout(bottom)

    def _toolset(self, buttons):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(3, 4, 3, 3)
        layout.setSpacing(7)
        for label, function, tip in buttons:
            layout.addWidget(make_button(label, function, "tool", tip))
        layout.addStretch()
        return page

    def _home_tools(self):
        return self._toolset([
            ("↶  Undo", self.undo_stack.undo, "Undo last change (Ctrl+Z)"),
            ("↷  Redo", self.undo_stack.redo, "Redo change (Ctrl+Y)"),
            ("B  Bold", self.toggle_bold, "Toggle bold on selected cells"),
            ("◩  Fill", self.fill_color, "Choose cell background"),
            ("A  Color", self.text_color, "Choose text color"),
            ("≡  Align", self.change_align, "Choose alignment"),
            ("€  Number", self.number_format, "Display as currency, percentage, etc."),
            ("⌕  Find", self.find_text, "Find a value in the active sheet"),
            ("✎  Replace", self.replace_text, "Replace text in the active sheet"),
        ])

    def _data_tools(self):
        return self._toolset([
            ("+ Row", self.insert_row, "Insert row above selection"),
            ("− Row", self.delete_row, "Delete selected row"),
            ("+ Column", self.insert_col, "Insert column before selection"),
            ("− Column", self.delete_col, "Delete selected column"),
            ("A → Z", lambda: self.sort_column(False), "Sort selected column ascending"),
            ("Z → A", lambda: self.sort_column(True), "Sort selected column descending"),
            ("⛃ Filter", self.filter_column, "Show rows matching text in column"),
            ("✧ Clean", self.clean_menu, "Clean, split, highlight, and organize your data"),
            ("Aa  Text", self.text_menu, "Change text case or remove surrounding spaces"),
        ])

    def _insert_tools(self):
        return self._toolset([
            ("📅  Today", self.insert_today, "Insert today’s date into the selected cell"),
            ("123  Series", self.number_series, "Fill a numeric sequence down a column"),
            ("▤  Table headers", self.quick_table, "Style the first row as a clear table header"),
            ("◉  Chart", self.make_chart, "Create a chart from the worksheet"),
            ("▦  Summary", self.group_data, "Build a grouped summary sheet"),
            ("＋  New sheet", self.add_sheet, "Add a new worksheet"),
        ])

    def _view_tools(self):
        return self._toolset([
            ("⌖  Go to cell", self.go_to_cell, "Jump directly to an address such as M450"),
            ("↔  Fit column", self.autosize_column, "Size the selected column to its contents"),
            ("↔  Fit all", self.autosize_all, "Size all used columns"),
            ("▥  Row stripes", self.toggle_banding, "Toggle alternating row shading"),
            ("⛶  Full screen", self.toggle_fullscreen, "Hide window chrome (F11 to toggle)"),
        ])

    def _insights_tools(self):
        return self._toolset([
            ("Σ  Calculate", self.calculate, "Sum, average, min, max, count without formulas"),
            ("◉  Chart", self.make_chart, "Create a chart in a few clicks"),
            ("▦  Group & summarize", self.group_data, "Make a summary worksheet by category"),
            ("◈  Duplicate sheet", self.duplicate_sheet, "Copy the whole current worksheet"),
            ("✎  Rename", lambda: self.rename_sheet(self.book.active), "Rename active worksheet"),
            ("×  Delete sheet", self.delete_sheet, "Remove current worksheet"),
        ])

    def _smart_tools(self):
        return self._toolset([
            ("▤  Column reports", self.reports_menu, "Frequency tables, unique lists and data profiles"),
            ("⇄  Transform", self.transform_menu, "Combine, transpose and convert data"),
            ("◈  Highlight", self.highlight_menu, "Find gaps, thresholds and unusual numbers"),
            ("▦  Tidy up", self.tidy_menu, "Remove empty rows and columns safely"),
            ("▣  Dates", self.date_series, "Fill a calendar sequence without formulas"),
        ])

    def _bind_shortcuts(self):
        for sequence, function in [("Ctrl+S", self.save), ("Ctrl+O", self.choose_open),
                                    ("Ctrl+N", self.new_book), ("Ctrl+Z", self.undo_stack.undo),
                                    ("Ctrl+Y", self.undo_stack.redo), ("Ctrl+F", self.find_text),
                                    ("Ctrl+H", self.replace_text), ("Ctrl+Shift+S", self.save_as),
                                    ("Ctrl+G", self.go_to_cell), ("F11", self.toggle_fullscreen),
                                    ("Esc", self.exit_fullscreen)]:
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(function)

    def _init_model(self):
        self.tabs.blockSignals(True)
        while self.tabs.count():
            self.tabs.removeTab(0)
        for sheet in self.book.sheets:
            self.tabs.addTab(sheet.name)
        self.tabs.setCurrentIndex(self.book.active)
        self.tabs.blockSignals(False)
        self.model = SheetModel(self.book.sheets[self.book.active], self.undo_stack, self.changed, self)
        self.model.theme = self.theme
        self.proxy = ColumnFilter(self)
        self.proxy.setSourceModel(self.model)
        self._restoring_columns = True
        self.grid.setModel(self.proxy)
        self.grid.selectionModel().selectionChanged.connect(self.on_selection)
        for column, width in self.model.sheet.widths.items():
            self.grid.setColumnWidth(int(column), int(width))
        self._restoring_columns = False
        self.on_selection()
        self._refresh_summary()

    def switch_sheet(self, index):
        if index < 0 or index >= len(self.book.sheets) or index == self.book.active:
            return
        self.book.active = index
        self.undo_stack.clear()  # Never apply an old sheet command to another sheet model.
        self._init_model()

    @property
    def sheet(self):
        return self.book.sheets[self.book.active]

    def changed(self):
        self.dirty = True
        self._update_title()
        self._refresh_summary()
        self.on_selection()

    def _update_title(self):
        filename = Path(self.path).name if self.path else "Untitled workbook"
        self.file_label.setText(("● " if self.dirty else "") + filename)
        self.setWindowTitle(f"{'● ' if self.dirty else ''}{filename} · Zovanion LunaGrid")

    def _refresh_summary(self):
        self.stat_cells.setText(f"{sum(len(x.cells) for x in self.book.sheets):,} filled cells")
        self.stat_sheets.setText(f"{len(self.book.sheets)} {'sheet' if len(self.book.sheets) == 1 else 'sheets'}")

    def on_selection(self, *args):
        if not hasattr(self, "grid") or self.grid.model() is None:
            return
        indexes = self.source_indexes()
        vals = [self.sheet.get(i.row(), i.column()) for i in indexes]
        metrics = core.statistics(vals)
        self.selection_stats.setText(f"SUM  {metrics['sum']:,.2f}     AVG  {metrics['average']:,.2f}  "
                                     f"   COUNT  {metrics['count']}" if metrics["average"] is not None
                                     else f"SUM  —     AVG  —     COUNT  {metrics['count']}")
        self.status.setText(f"{len(indexes)} cells selected  ·  {self.proxy.rowCount():,} visible rows  ·  "
                            f"{self.sheet.cols} columns")

    def source_indexes(self):
        selection = self.grid.selectionModel()
        if not selection:
            return []
        return sorted((self.proxy.mapToSource(idx) for idx in selection.selectedIndexes()),
                      key=lambda ix: (ix.row(), ix.column()))

    def selected_anchor(self):
        selected = self.source_indexes()
        if selected:
            return selected[0].row(), selected[0].column()
        index = self.grid.currentIndex()
        if index.isValid():
            mapped = self.proxy.mapToSource(index)
            return mapped.row(), mapped.column()
        return 0, 0

    def selected_col(self):
        return self.selected_anchor()[1]

    def bulk(self, name, operation: Callable):
        before = self.sheet.snapshot()
        try:
            outcome = operation()
        except Exception as error:
            self.sheet.restore(before)
            self.model.refresh()
            QMessageBox.warning(self, "Action unavailable", str(error))
            return None
        after = self.sheet.snapshot()
        if before != after:
            self.undo_stack.push(BulkCommand(self.model, name, before, after))
        return outcome

    def apply_style(self, changes):
        selected = self.source_indexes()
        if not selected:
            QMessageBox.information(self, "Select some cells", "Select one or more cells first.")
            return
        if len(selected) > 100_000:
            QMessageBox.warning(self, "Large selection", "Select up to 100,000 cells for a formatting action.")
            return
        def op():
            for index in selected:
                self.sheet.set_style(index.row(), index.column(), changes)
        self.bulk("Format cells", op)

    def toggle_bold(self):
        row, col = self.selected_anchor()
        self.apply_style({"bold": not self.sheet.style(row, col).get("bold", False)})

    def fill_color(self):
        color = QColorDialog.getColor(QColor(THEMES[self.theme]["accent_pale"]), self, "Cell fill color")
        if color.isValid():
            self.apply_style({"fill": color.name()})

    def text_color(self):
        color = QColorDialog.getColor(QColor(THEMES[self.theme]["text"]), self, "Text color")
        if color.isValid():
            self.apply_style({"text": color.name()})

    def change_align(self):
        choice, ok = QInputDialog.getItem(self, "Align selected cells", "Alignment", ["left", "center", "right"], 0, False)
        if ok:
            self.apply_style({"align": choice})

    def number_format(self):
        options = ["General", "Number (2 decimals)", "Whole number", "Euro (€)", "Percent (%)", "Date"]
        choice, ok = QInputDialog.getItem(self, "Number format", "Display selected cells as", options, 0, False)
        if ok:
            choice_map = dict(zip(options, ["general", "number", "integer", "currency", "percent", "date"]))
            self.apply_style({"format": choice_map[choice]})

    def insert_row(self):
        at, _ = self.selected_anchor()
        self.bulk("Insert row", lambda: self.sheet.insert_rows(at))

    def delete_row(self):
        at, _ = self.selected_anchor()
        self.bulk("Delete row", lambda: self.sheet.delete_rows(at))

    def insert_col(self):
        _, at = self.selected_anchor()
        self.bulk("Insert column", lambda: self.sheet.insert_cols(at))

    def delete_col(self):
        _, at = self.selected_anchor()
        self.bulk("Delete column", lambda: self.sheet.delete_cols(at))

    def sort_column(self, descending):
        col = self.selected_col()
        if self.proxy.column != -1:
            self.clear_filter()
        self.bulk("Sort rows", lambda: self.sheet.sort_by(col, reverse=descending))

    def filter_column(self):
        col = self.selected_col()
        value, ok = QInputDialog.getText(self, f"Filter column {core.column_label(col)}", "Show rows containing")
        if ok:
            self.proxy.set_column_filter(col, value)
            self.filter_badge.setText(f"{core.column_label(col)} contains '{value}'" if value else "All rows visible")
            self.on_selection()

    def clear_filter(self):
        if hasattr(self, "proxy"):
            self.proxy.set_column_filter(-1, "")
            self.filter_badge.setText("All rows visible")
            self.on_selection()

    def copy_cells(self):
        indexes = self.source_indexes()
        if not indexes:
            return
        r0, r1 = min(i.row() for i in indexes), max(i.row() for i in indexes)
        c0, c1 = min(i.column() for i in indexes), max(i.column() for i in indexes)
        if (r1 - r0 + 1) * (c1 - c0 + 1) > 250_000:
            QMessageBox.warning(self, "Too many cells", "Copy up to 250,000 cells at a time.")
            return
        selected = {(i.row(), i.column()) for i in indexes}
        buffer = io.StringIO()
        writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
        for r in range(r0, r1 + 1):
            writer.writerow([str(self.sheet.get(r, c)) if (r, c) in selected and self.sheet.get(r, c) is not None else ""
                             for c in range(c0, c1 + 1)])
        QApplication.clipboard().setText(buffer.getvalue())

    def paste_cells(self):
        text = QApplication.clipboard().text()
        if not text:
            return
        rows = list(csv.reader(io.StringIO(text), delimiter="\t"))
        while rows and not any(rows[-1]):
            rows.pop()
        if not rows:
            return
        r0, c0 = self.selected_anchor()
        ncol = max(map(len, rows))
        if len(rows) * ncol > 250_000:
            QMessageBox.warning(self, "Too much data", "Paste up to 250,000 cells at a time.")
            return
        def op():
            self.sheet.ensure(r0 + len(rows), c0 + ncol)
            for row, contents in enumerate(rows):
                for col, value in enumerate(contents):
                    self.sheet.put(r0 + row, c0 + col, core.parse_input(value))
        self.bulk("Paste cells", op)

    def clear_cells(self):
        selected = self.source_indexes()
        if not selected:
            return
        self.bulk("Clear selected values", lambda: [self.sheet.put(i.row(), i.column(), None) for i in selected])

    def find_text(self):
        text, ok = QInputDialog.getText(self, "Find", "Find value in this sheet")
        if not ok or not text:
            return
        needle = text.casefold()
        for address, value in sorted(self.sheet.cells.items(), key=lambda kv: core.split_key(kv[0])):
            if needle in str(value).casefold():
                r, c = core.split_key(address)
                idx = self.proxy.mapFromSource(self.model.index(r, c))
                if not idx.isValid():
                    self.clear_filter()
                    idx = self.proxy.mapFromSource(self.model.index(r, c))
                self.grid.setCurrentIndex(idx)
                self.grid.scrollTo(idx, QAbstractItemView.ScrollHint.PositionAtCenter)
                return
        QMessageBox.information(self, "Not found", f"No cells contain '{text}'.")

    def replace_text(self):
        find, ok = QInputDialog.getText(self, "Find and replace", "Find")
        if not ok or not find:
            return
        replacement, ok = QInputDialog.getText(self, "Find and replace", "Replace with")
        if not ok:
            return
        count = 0
        def op():
            nonlocal count
            for address, value in list(self.sheet.cells.items()):
                if find.casefold() in str(value).casefold():
                    new, hits = re.subn(re.escape(find), lambda _: replacement,
                                                       str(value), flags=re.IGNORECASE)
                    if hits:
                        r, c = core.split_key(address)
                        self.sheet.put(r, c, core.parse_input(new))
                        count += 1
        self.bulk("Replace text", op)
        self.status.setText(f"Replaced text in {count} cells")

    def clean_menu(self):
        menu = QMenu(self)
        menu.addAction("Trim surrounding spaces", self.trim_spaces)
        menu.addAction("Split text into columns…", self.split_column)
        menu.addAction("Highlight duplicates in this column", self.highlight_duplicates)
        menu.addAction("Change selected text…", self.text_menu)
        menu.addAction("Remove duplicate rows", self.remove_duplicates)
        menu.addAction("Fill empty cells downward", self.fill_down)
        menu.addAction("Toggle alternating row shades", self.toggle_banding)
        menu.addAction("Clear selected formatting", self.clear_formatting)
        menu.addAction("Auto-size selected column", self.autosize_column)
        menu.addAction("Auto-size all used columns", self.autosize_all)
        menu.addSeparator()
        menu.addAction("More data tools…", self.transform_menu)
        menu.addAction("Data reports…", self.reports_menu)
        menu.addAction("Highlight & detect…", self.highlight_menu)
        menu.addAction("Tidy rows & columns…", self.tidy_menu)
        menu.addAction("Add 100 rows to bottom", self.extend_rows)
        menu.exec(self.cursor().pos())

    def clear_formatting(self):
        selected = self.source_indexes()
        if selected:
            self.bulk("Clear formatting", lambda: [self.sheet.styles.pop(core.key(i.row(), i.column()), None) for i in selected])

    def autosize_column(self):
        column = self.selected_col()
        values = [str(v) for address, v in self.sheet.cells.items() if core.split_key(address)[1] == column]
        width = min(460, max(85, max((len(v) for v in values), default=8) * 9 + 28))
        self.grid.setColumnWidth(column, width)

    def autosize_all(self):
        """Size occupied columns, capped for readability and quick response."""
        widths = {}
        for addr, value in self.sheet.cells.items():
            _, col = core.split_key(addr)
            widths[col] = max(widths.get(col, 0), len(str(value)))
        if not widths:
            self.status.setText("There is no content to auto-size yet")
            return
        for col, characters in widths.items():
            self.grid.setColumnWidth(col, min(430, max(92, characters * 9 + 28)))
        self.status.setText(f"Auto-sized {len(widths)} used columns")

    def quick_table(self):
        if not any(core.split_key(a)[0] == 0 for a in self.sheet.cells):
            QMessageBox.information(self, "Add column names first", "Type your column headings into row 1, then click Table headers.")
            return
        count = self.bulk("Style table headers", lambda: core.format_header_row(self.sheet))
        if count:
            self.status.setText(f"Styled {count} column headers")

    def insert_today(self):
        row, col = self.selected_anchor()
        today = date.today().isoformat()
        self.bulk("Insert today's date", lambda: self.sheet.put(row, col, today))
        self.status.setText(f"Inserted {today}")

    def number_series(self):
        row, col = self.selected_anchor()
        dialog = QDialog(self)
        dialog.setWindowTitle("Fill number series")
        layout = QVBoxLayout(dialog)
        heading = QLabel("Create a number sequence")
        heading.setObjectName("hero")
        layout.addWidget(heading)
        layout.addWidget(QLabel(f"Starting at {core.column_label(col)}{row + 1}. The values remain editable."))
        form = QFormLayout()
        start = QDoubleSpinBox(dialog)
        start.setRange(-1_000_000_000, 1_000_000_000)
        start.setDecimals(4)
        existing = core.number(self.sheet.get(row, col))
        start.setValue(existing if existing is not None else 1)
        step = QDoubleSpinBox(dialog)
        step.setRange(-1_000_000, 1_000_000)
        step.setDecimals(4)
        step.setValue(1)
        count = QSpinBox(dialog)
        count.setRange(1, min(10_000, core.MAX_ROWS - row))
        count.setValue(min(10, core.MAX_ROWS - row))
        form.addRow("Start at", start)
        form.addRow("Increase by", step)
        form.addRow("Number of rows", count)
        layout.addLayout(form)
        actions = QHBoxLayout()
        actions.addStretch()
        actions.addWidget(make_button("Cancel", dialog.reject, "quiet"))
        actions.addWidget(make_button("Fill cells", dialog.accept, "primary"))
        layout.addLayout(actions)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.bulk("Fill number series", lambda: core.fill_number_series(
                self.sheet, row, col, count.value(), start.value(), step.value()))

    def split_column(self):
        col = self.selected_col()
        chosen, ok = QInputDialog.getItem(self, "Split into columns", "Separate text using",
                                           ["Comma ,", "Semicolon ;", "Space", "Tab", "Pipe |", "Custom…"], 0, False)
        if not ok:
            return
        separators = {"Comma ,": ",", "Semicolon ;": ";", "Space": " ", "Tab": "\t", "Pipe |": "|"}
        separator = separators.get(chosen)
        if separator is None:
            separator, ok = QInputDialog.getText(self, "Custom separator", "Type the separator")
            if not ok or not separator:
                return
        extra = self.bulk("Split text into columns", lambda: core.split_text_column(self.sheet, col, separator))
        if extra == 0:
            QMessageBox.information(self, "No matches", "No cells in that column contain the chosen separator.")
        elif extra is not None:
            self.status.setText(f"Split column {core.column_label(col)} into {extra + 1} columns, without overwriting adjacent data")

    def text_menu(self):
        chosen, ok = QInputDialog.getItem(self, "Text tools", "Change selected text to",
                                          ["UPPERCASE", "lowercase", "Title Case", "Trim spaces"], 0, False)
        if not ok:
            return
        selected = self.source_indexes()
        if not selected:
            QMessageBox.information(self, "Select cells first", "Select the cells whose text you want to change.")
            return
        coords = [(i.row(), i.column()) for i in selected]
        updated = self.bulk("Transform text", lambda: core.transform_text_cells(self.sheet, coords, chosen))
        if updated is not None:
            self.status.setText(f"Updated {updated} text cells")

    def highlight_duplicates(self):
        col = self.selected_col()
        count = self.bulk("Highlight duplicates", lambda: core.highlight_duplicate_values(self.sheet, col))
        if count is not None:
            self.status.setText(f"Highlighted {count} duplicate entries in column {core.column_label(col)}")
            if count == 0:
                QMessageBox.information(self, "No duplicates", "No repeated nonempty values were found below row 1.")

    def _report_sheet(self, title, factory):
        if len(self.book.sheets) >= core.MAX_SHEETS:
            QMessageBox.warning(self, "Too many worksheets", "The workbook has reached the sheet limit.")
            return
        try:
            new_sheet = factory()
        except (ValueError, OverflowError) as exc:
            QMessageBox.warning(self, "Could not create report", str(exc))
            return
        new_sheet.name = self.book.unique_name(new_sheet.name)
        self.book.sheets.append(new_sheet)
        self.book.active = len(self.book.sheets) - 1
        self._init_model()
        self.changed()
        self.status.setText(f"Created {title} worksheet")

    def reports_menu(self):
        menu = QMenu(self)
        menu.addAction("Full data quality report", lambda: self._report_sheet("data profile", lambda: core.column_profile_sheet(self.sheet)))
        menu.addAction("Count values in selected column", lambda: self._report_sheet("frequency table", lambda: core.frequency_table_sheet(self.sheet, self.selected_col())))
        menu.addAction("List unique values in selected column", lambda: self._report_sheet("unique values", lambda: core.unique_values_sheet(self.sheet, self.selected_col())))
        menu.addAction("Group by category & summarize", self.group_data)
        menu.addAction("Create a chart", self.make_chart)
        menu.exec(self.cursor().pos())

    def transform_menu(self):
        menu = QMenu(self)
        menu.addAction("Combine two columns…", self.combine_columns)
        menu.addAction("Transpose selected cells into a new sheet", self.transpose_selection)
        menu.addAction("Convert numeric text to numbers", self.convert_numbers)
        menu.addAction("Collapse extra spaces", self.collapse_spaces)
        menu.addAction("Split selected column…", self.split_column)
        menu.addAction("Change text case…", self.text_menu)
        menu.exec(self.cursor().pos())

    def highlight_menu(self):
        menu = QMenu(self)
        menu.addAction("Highlight duplicate values", self.highlight_duplicates)
        menu.addAction("Highlight blank cells", lambda: self._highlight_result("Find blank cells", lambda: core.highlight_blanks(self.sheet, self.selected_col())))
        menu.addAction("Highlight values above or below…", self.highlight_threshold)
        menu.addAction("Highlight unusual values (outliers)", lambda: self._highlight_result("Find unusual numbers", lambda: core.highlight_outliers(self.sheet, self.selected_col())))
        menu.exec(self.cursor().pos())

    def tidy_menu(self):
        menu = QMenu(self)
        menu.addAction("Remove empty rows within data", lambda: self._tidy_result("Remove empty rows", lambda: core.remove_empty_rows(self.sheet)))
        menu.addAction("Remove empty columns within data", lambda: self._tidy_result("Remove empty columns", lambda: core.remove_empty_columns(self.sheet)))
        menu.addAction("Remove duplicate rows", self.remove_duplicates)
        menu.addAction("Clear selected formatting", self.clear_formatting)
        menu.addAction("Auto-size used columns", self.autosize_all)
        menu.exec(self.cursor().pos())

    def _tidy_result(self, name, operation):
        result = self.bulk(name, operation)
        if result is not None:
            self.status.setText(f"{name}: {result}")

    def _highlight_result(self, title, operation):
        result = self.bulk(title, operation)
        if result is not None:
            self.status.setText(f"Highlighted {result} matching cells")

    def transpose_selection(self):
        cells = self.source_indexes()
        if not cells:
            QMessageBox.information(self, "Select cells", "Select a rectangular area first.")
            return
        rows, cols = [i.row() for i in cells], [i.column() for i in cells]
        top, bottom, left, right = min(rows), max(rows), min(cols), max(cols)
        if (bottom - top + 1) * (right - left + 1) != len(cells):
            QMessageBox.information(self, "Select a rectangle", "Select one continuous rectangular area.")
            return
        self._report_sheet("transposed data", lambda: core.transpose_selection(self.sheet, top, left, bottom, right))

    def combine_columns(self):
        if self.sheet.cols < 2:
            QMessageBox.information(self, "Add another column", "Two input columns are needed.")
            return
        columns = [f"{core.column_label(c)} · {self.sheet.get(0,c) or 'Column'}" for c in range(self.sheet.cols)]
        first, ok = QInputDialog.getItem(self, "Combine columns", "First column", columns, self.selected_col(), False)
        if not ok:
            return
        a = columns.index(first)
        second, ok = QInputDialog.getItem(self, "Combine columns", "Second column", columns, min(a + 1, self.sheet.cols - 1), False)
        if not ok:
            return
        b = columns.index(second)
        separator, ok = QInputDialog.getText(self, "Combine columns", "Text between values", text=" ")
        if not ok:
            return
        result = self.bulk("Combine columns", lambda: core.combine_columns(self.sheet, a, b, separator))
        if result is not None:
            self.status.setText(f"Combined data into column {core.column_label(result)}; existing data preserved")

    def _selected_positions(self):
        cells = self.source_indexes()
        if not cells:
            QMessageBox.information(self, "Select cells", "Select one or more cells first.")
            return None
        return [(i.row(), i.column()) for i in cells]

    def convert_numbers(self):
        points = self._selected_positions()
        if points is not None:
            self._tidy_result("Convert numeric text", lambda: core.convert_numeric_text(self.sheet, points))

    def collapse_spaces(self):
        points = self._selected_positions()
        if points is not None:
            self._tidy_result("Collapse extra spaces", lambda: core.normalize_whitespace(self.sheet, points))

    def highlight_threshold(self):
        comparator, ok = QInputDialog.getItem(self, "Highlight numbers", "Highlight values", ["Above", "Below", "Equal"], 0, False)
        if not ok:
            return
        threshold, ok = QInputDialog.getDouble(self, "Highlight numbers", "Value", 0.0, -1e12, 1e12, 3)
        if not ok:
            return
        self._highlight_result("Highlight matching numbers", lambda: core.highlight_by_rule(self.sheet, self.selected_col(), comparator, threshold))

    def date_series(self):
        r, c = self.selected_anchor()
        first, ok = QInputDialog.getText(self, "Fill dates", "Start date (YYYY-MM-DD)", text=date.today().isoformat())
        if not ok:
            return
        try:
            start = date.fromisoformat(first.strip())
        except ValueError:
            QMessageBox.warning(self, "Invalid date", "Use YYYY-MM-DD, for example 2026-11-01.")
            return
        count, ok = QInputDialog.getInt(self, "Fill dates", "Number of dates", 14, 1, min(10_000, core.MAX_ROWS - r))
        if not ok:
            return
        every, ok = QInputDialog.getInt(self, "Fill dates", "Days between dates", 1, 1, 3650)
        if ok:
            self.bulk("Fill date series", lambda: core.fill_date_series(self.sheet, r, c, count, start, every))

    def go_to_cell(self):
        r, c = self.selected_anchor()
        value, ok = QInputDialog.getText(self, "Go to cell", "Cell address (e.g. B12 or AA100)",
                                          text=f"{core.column_label(c)}{r + 1}")
        if not ok:
            return
        match = re.fullmatch(r"\s*([A-Za-z]{1,3})([1-9][0-9]*)\s*", value)
        if not match:
            QMessageBox.warning(self, "Invalid address", "Enter a cell reference such as A1, D42 or AA100.")
            return
        col = 0
        for char in match.group(1).upper():
            col = col * 26 + (ord(char) - 64)
        col -= 1
        row = int(match.group(2)) - 1
        if row >= core.MAX_ROWS or col >= core.MAX_COLS:
            QMessageBox.warning(self, "Cell outside supported size",
                                f"LunaGrid supports up to {core.MAX_ROWS:,} rows and {core.MAX_COLS} columns.")
            return
        if row >= self.sheet.rows or col >= self.sheet.cols:
            self.bulk("Extend worksheet", lambda: self.sheet.ensure(row + 1, col + 1))
        index = self.proxy.mapFromSource(self.model.index(row, col))
        if not index.isValid():
            self.clear_filter()
            index = self.proxy.mapFromSource(self.model.index(row, col))
        self.grid.setCurrentIndex(index)
        self.grid.scrollTo(index, QAbstractItemView.ScrollHint.PositionAtCenter)
        self.grid.setFocus()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showMaximized()
        else:
            self.showFullScreen()
        self.screen_button.setText("⤢ Windowed" if self.isFullScreen() else "⛶ Full screen")

    def exit_fullscreen(self):
        if self.isFullScreen():
            self.toggle_fullscreen()

    def extend_rows(self):
        self.bulk("Add 100 rows", lambda: self.sheet.insert_rows(self.sheet.rows, 100))

    def trim_spaces(self):
        def op():
            for k, value in list(self.sheet.cells.items()):
                if isinstance(value, str):
                    self.sheet.cells[k] = value.strip()
        self.bulk("Trim whitespace", op)

    def remove_duplicates(self):
        result = self.bulk("Remove duplicate rows", lambda: self.sheet.remove_duplicates())
        if result is not None:
            QMessageBox.information(self, "Duplicates removed", f"Removed {result} duplicate rows. Undo is available.")

    def fill_down(self):
        indices = self.source_indexes()
        if not indices:
            QMessageBox.information(self, "Select a range", "Select the empty cells to fill down first.")
            return
        def op():
            for i in indices:
                if self.sheet.get(i.row(), i.column()) is None:
                    r = i.row() - 1
                    while r >= 0 and self.sheet.get(r, i.column()) is None:
                        r -= 1
                    if r >= 0:
                        self.sheet.put(i.row(), i.column(), self.sheet.get(r, i.column()))
        self.bulk("Fill down", op)

    def toggle_banding(self):
        self.bulk("Toggle banded rows", lambda: setattr(self.sheet, "banded", not self.sheet.banded))

    def calculate(self):
        selected = self.source_indexes()
        if selected:
            values = [self.sheet.get(i.row(), i.column()) for i in selected]
            anchor = max(i.row() for i in selected) + 1, selected[0].column()
        else:
            col = self.selected_col()
            values = [self.sheet.get(r, col) for r in range(1, self.sheet.rows)]
            anchor = max((core.split_key(k)[0] for k in self.sheet.cells if core.split_key(k)[1] == col), default=0) + 1, col
        stats = core.statistics(values)
        dlg = QDialog(self)
        dlg.setWindowTitle("One-click calculations")
        layout = QVBoxLayout(dlg)
        title = QLabel("No formulas. Just answers.")
        title.setObjectName("hero")
        layout.addWidget(title)
        keys = [("Sum", "sum"), ("Average", "average"), ("Minimum", "minimum"),
                ("Maximum", "maximum"), ("Numeric count", "count"),
                ("Filled cells", "nonblank"), ("Unique values", "unique")]
        chosen = QComboBox()
        for label, key in keys:
            chosen.addItem(label, key)
        result = QLabel()
        result.setStyleSheet(f"color:{THEMES[self.theme]['accent']};font-size:31px;font-weight:800;padding:20px;")
        def update():
            val = stats[chosen.currentData()]
            result.setText("—" if val is None else ((f"{val:,.4f}".rstrip("0").rstrip(".")) or "0") if isinstance(val, float) else str(val))
        chosen.currentIndexChanged.connect(update)
        update()
        layout.addWidget(QLabel("CALCULATION"))
        layout.addWidget(chosen)
        layout.addWidget(result)
        hint = QLabel("Insert the result into the first free row below the selection, or simply use it here.")
        hint.setObjectName("caption")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        controls = QHBoxLayout()
        insert = make_button("Insert into sheet", lambda: dlg.done(2), "primary")
        controls.addWidget(make_button("Close", dlg.reject, "quiet"))
        controls.addWidget(insert)
        layout.addLayout(controls)
        if dlg.exec() == 2:
            result_value = stats[chosen.currentData()]
            if result_value is not None:
                r, c = anchor
                self.bulk("Insert calculation", lambda: self.sheet.put(r, c, result_value))

    def make_chart(self):
        ChartDialog(self.sheet, self, theme=self.theme).exec()

    def group_data(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Group & summarize")
        box = QVBoxLayout(dialog)
        heading = QLabel("Build a summary worksheet")
        heading.setObjectName("hero")
        box.addWidget(heading)
        form = QFormLayout()
        group = QComboBox()
        metric = QComboBox()
        for col in range(self.sheet.cols):
            title = self.sheet.get(0, col)
            text = f"{core.column_label(col)}  ·  {str(title)[:30] if title is not None else 'Column'}"
            group.addItem(text, col)
            metric.addItem(text, col)
        metric.setCurrentIndex(min(1, self.sheet.cols - 1))
        calc = QComboBox()
        calc.addItems(["Sum", "Average", "Count", "Min", "Max"])
        form.addRow("Group by", group)
        form.addRow("Values from", metric)
        form.addRow("Calculation", calc)
        box.addLayout(form)
        box.addWidget(QLabel("The first row is treated as column headers."))
        buttons = QHBoxLayout()
        buttons.addWidget(make_button("Cancel", dialog.reject, "quiet"))
        buttons.addWidget(make_button("Create worksheet", dialog.accept, "primary"))
        box.addLayout(buttons)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            summary = self.sheet.group_summary(group.currentData(), metric.currentData(), calc.currentText().lower())
            summary.name = self.book.unique_name("Summary")
            self.book.sheets.append(summary)
            self.book.active = len(self.book.sheets) - 1
            self._init_model()
            self.changed()

    def add_sheet(self):
        if len(self.book.sheets) >= core.MAX_SHEETS:
            QMessageBox.warning(self, "Sheet limit", "This workbook has reached the sheet limit.")
            return
        self.book.sheets.append(core.Sheet(name=self.book.unique_name("Sheet")))
        self.book.active = len(self.book.sheets) - 1
        self._init_model()
        self.changed()

    def duplicate_sheet(self):
        if len(self.book.sheets) >= core.MAX_SHEETS:
            return
        duplicate = core.Sheet.from_dict(self.sheet.snapshot())
        duplicate.name = self.book.unique_name(self.sheet.name + " copy")
        self.book.sheets.append(duplicate)
        self.book.active = len(self.book.sheets) - 1
        self._init_model()
        self.changed()

    def rename_sheet(self, index):
        if not 0 <= index < len(self.book.sheets):
            return
        target = self.book.sheets[index]
        value, ok = QInputDialog.getText(self, "Rename worksheet", "Worksheet name", text=target.name)
        if ok and value.strip():
            new_name = self.book.unique_name(value.strip()[:100], exclude=target)
            if new_name != target.name:
                target.name = new_name
                self.tabs.setTabText(index, new_name)
                self.changed()

    def delete_sheet(self):
        if len(self.book.sheets) == 1:
            QMessageBox.information(self, "Keep one worksheet", "A workbook needs at least one worksheet.")
            return
        answer = QMessageBox.question(self, "Delete worksheet", f"Delete '{self.sheet.name}' and its data? This cannot be undone.")
        if answer == QMessageBox.StandardButton.Yes:
            self.book.sheets.pop(self.book.active)
            self.book.active = min(self.book.active, len(self.book.sheets) - 1)
            self.undo_stack.clear()
            self._init_model()
            self.changed()

    def grid_menu(self, pos):
        menu = QMenu(self)
        for label, fn in [("Copy", self.copy_cells), ("Paste", self.paste_cells), ("Clear cells", self.clear_cells),
                          ("Bold", self.toggle_bold), ("Fill color", self.fill_color),
                          ("Insert row", self.insert_row), ("Insert column", self.insert_col),
                          ("Sort A → Z", lambda: self.sort_column(False)),
                          ("Filter this column", self.filter_column), ("Calculate", self.calculate),
                          ("Number series…", self.number_series), ("Text tools…", self.text_menu)]:
            menu.addAction(label, fn)
        menu.exec(self.grid.viewport().mapToGlobal(pos))

    def remember_width(self, index, old, width):
        if not getattr(self, "_restoring_columns", True) and 0 <= index < self.sheet.cols:
            if self.sheet.widths.get(str(index)) != width:
                self.sheet.widths[str(index)] = width
                self.dirty = True
                self._update_title()

    def show_file_menu(self):
        menu = QMenu(self)
        menu.addAction("Open workbook…", self.choose_open)
        menu.addAction("Save as native .luma…", self.save_as)
        menu.addAction("Export Excel .xlsx…", self.export_excel)
        menu.addAction("Export current sheet as CSV…", self.export_csv)
        menu.addSeparator()
        menu.addAction("Associate .luma files with this app", self.associate_files)
        menu.addAction("About Zovanion LunaGrid", self.about)
        menu.addSeparator()
        menu.addAction("Exit LunaGrid", self.close)
        menu.exec(self.more_button.mapToGlobal(QPoint(0, self.more_button.height())))

    def about(self):
        QMessageBox.information(self, "About Zovanion LunaGrid", "Zovanion LunaGrid 1.2\n\n"
            "Local-first, click-driven spreadsheet editor.\n"
            "Native format: .luma · Excel: .xlsx · Data: .csv\n\n"
            "Excel formulas/macros, pivot tables, external links and collaborative editing are not implemented. "
            "Importing Excel uses stored cell values; formula calculation is not performed.")

    def associate_files(self):
        if sys.platform != "win32":
            QMessageBox.information(self, "Windows feature", "File association works on Windows builds only.")
            return
        if not getattr(sys, "frozen", False):
            QMessageBox.information(self, "Build required", "Compile the app into LunaGrid.exe first, then enable file association.")
            return
        try:
            native_file_association(sys.executable)
            QMessageBox.information(self, "File association registered",
                "Zovanion LunaGrid has been registered as an app for .luma files.\n\n"
                "On Windows 11, you may also need Settings → Apps → Default apps → .luma → LunaGrid "
                "before double-click opens directly here.")
        except Exception as error:
            QMessageBox.warning(self, "Association failed", str(error))

    def choose_open(self):
        if not self.confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Open workbook", "", "Workbooks (*.luma *.xlsx *.xlsm *.csv *.tsv);;LunaGrid (*.luma);;Excel (*.xlsx *.xlsm);;CSV (*.csv *.tsv)")
        if path:
            self.open_path(path, already_confirmed=True)

    def open_path(self, path, already_confirmed=False):
        if not already_confirmed and not self.confirm_discard():
            return
        try:
            loaded = core.load_file(path)
        except Exception as error:
            QMessageBox.critical(self, "Unable to open workbook", str(error))
            return
        self.book = loaded
        self.path = str(Path(path).resolve()) if str(path).lower().endswith(".luma") else None
        self.dirty = False
        self.undo_stack.clear()
        self._init_model()
        self._update_title()
        if not self.path:
            self.file_label.setText(f"Imported {Path(path).name} · Save as .luma")
            if str(path).lower().endswith(".xlsm"):
                QMessageBox.information(self, "Macros not imported", "The data was imported. Excel macros and formula calculations are not supported.")

    def new_book(self):
        if not self.confirm_discard():
            return
        self.book = core.Book()
        self.path = None
        self.dirty = False
        self.undo_stack.clear()
        self._init_model()
        self._update_title()

    def confirm_discard(self):
        if not self.dirty:
            return True
        answer = QMessageBox.question(self, "Save changes?", "This workbook contains unsaved changes.",
                 QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                 QMessageBox.StandardButton.Save)
        if answer == QMessageBox.StandardButton.Cancel:
            return False
        if answer == QMessageBox.StandardButton.Save:
            return self.save()
        # Discard means discard: never leave a recovery file that restores these changes.
        self.dirty = False
        try:
            Path(self.recovery_path).unlink(missing_ok=True)
        except OSError:
            pass
        return True

    def save(self):
        if not self.path:
            return self.save_as()
        try:
            core.save_native(self.book, self.path)
            self.dirty = False
            self._update_title()
            self.status.setText("Workbook saved successfully")
            return True
        except Exception as error:
            QMessageBox.critical(self, "Save failed", str(error))
            return False

    def save_as(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save LunaGrid workbook", self.path or "Untitled.luma", "LunaGrid workbook (*.luma)")
        if not path:
            return False
        if not path.lower().endswith(".luma"):
            path += ".luma"
        previous = self.path
        self.path = path
        if self.save():
            return True
        self.path = previous
        return False

    def export_excel(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Excel workbook", "LunaGrid-export.xlsx", "Excel workbook (*.xlsx)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            core.export_xlsx(self.book, path)
            self.status.setText(f"Excel export saved: {Path(path).name}")
            QMessageBox.information(self, "Excel export created", f"Exported {len(self.book.sheets)} worksheets to:\n{path}")
        except Exception as error:
            QMessageBox.critical(self, "Export failed", str(error))

    def export_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export current sheet", f"{self.sheet.name}.csv", "CSV file (*.csv)")
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            core.export_csv(self.sheet, path)
            self.status.setText(f"CSV export saved: {Path(path).name}")
        except Exception as error:
            QMessageBox.critical(self, "Export failed", str(error))

    def autosave(self):
        if not self.dirty:
            return
        try:
            core.save_native(self.book, self.recovery_path)
        except Exception:
            # Recovery is opportunistic; explicit saves always report errors.
            return

    def offer_recovery(self):
        path = Path(self.recovery_path)
        if not path.is_file():
            return
        try:
            book = core.load_native(str(path))
        except Exception:
            return
        answer = QMessageBox.question(self, "Recover your work?", "An automatically saved workbook was found. Restore it?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes)
        if answer == QMessageBox.StandardButton.Yes:
            self.book = book
            self.path = None
            self.undo_stack.clear()
            self.dirty = True
            self._init_model()
            self._update_title()
        else:
            try:
                path.unlink()
            except OSError:
                pass

    def closeEvent(self, event):
        if not self.confirm_discard():
            event.ignore()
            return
        if not self.dirty:
            try:
                Path(self.recovery_path).unlink(missing_ok=True)
            except OSError:
                pass
        else:
            self.autosave()
        event.accept()

    def dragEnterEvent(self, event):
        urls = event.mimeData().urls()
        if urls and urls[0].isLocalFile():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            self.open_path(urls[0].toLocalFile())
            event.acceptProposedAction()
