# Zovanion LunaGrid 1.3

**Zovanion LunaGrid** (short name **LunaGrid**) is a Windows-first desktop spreadsheet app, built using Python + Qt/PySide6. It aims to make common spreadsheet work approachable without manually typing formulas. Workbooks stay on your device by default.


## Added in 1.3

- **Chart crash fixed:** the chart value selector no longer overrides Qt’s `QWidget.metric()` drawing method (the cause of the `QComboBox object is not callable` exception). Bar, line, area and pie previews can be saved as PNG.
- **Maximized desktop launch:** splash screen first, then a standard maximized Windows window; F11 is optional true fullscreen.
- **More tools tab:** guided menus for data profiles, frequency reports, unique-value lists, combining columns, transposing a selection, converting numeric text, trimming extra internal whitespace, highlighting blanks and numeric thresholds, finding outliers, and removing internal empty rows/columns.
- **Calendar sequences:** fill a date series using a start date, count and step in days.
- **Undo-friendly operations:** destructive in-sheet actions use the existing workbook undo stack. Reports create new worksheets.
- **Compatibility:** native `.luma` format remains unchanged; LunaGrid 1.2 workbooks still open.

All these tools work with normal editable values; they do not implement an Excel formula engine, macros, pivot tables or live formula recalculation.

## Earlier changes (1.2)

- **Compact buttons and tighter ribbon spacing.** Shorter tool buttons, reduced vertical padding on the ribbon, tabs, header and worksheet panel, leaving more room for the grid.
- **Branded launch screen.** A brief **Zovanion LunaGrid** splash appears while the workspace is prepared. The program opens in a **maximized, normal Windows window** with title bar and taskbar. F11 is an optional borderless fullscreen toggle; Esc exits fullscreen.
- **Insert tab:** insert today's date, create editable number sequences (start/step/count), instantly format a table's heading row, add a sheet, and open chart/summary tools.
- **Data tab → Text:** change selected text to UPPERCASE, lowercase, Title Case or trim spaces; results are undoable.
- **Data tab → Clean:** split a column by comma, semicolon, space, tab, pipe or a custom separator; extra columns are *inserted* to protect nearby data. Highlight repeated values in one column. Existing deduplicate, fill-down, auto-size, and cleanup tools remain.
- **View tab:** Go to cell (Ctrl+G), auto-size one/all populated columns, toggle row stripes, and enter/leave fullscreen.
- **Undo support** for new data operations, plus tests for column shifting, duplicate identification, text transformations and numeric sequences.

## Building the Windows EXE

1. Download and extract the source ZIP to a writable folder on **Windows 10 or 11**.
2. Install **Python 3.12 or 3.13 for Windows**, including the `py` launcher (https://www.python.org/downloads/windows/).
3. Double-click **`build_windows.bat`**. The build script creates a local `.venv`, installs the dependencies, and runs PyInstaller.
4. Your executable is **`dist\LunaGrid.exe`**. Launch it directly.

This uses `--onefile --windowed` to package a *single* Windows GUI EXE. **The app does not open a CMD window.** The **build script** itself needs a visible terminal for status and errors. PyInstaller one-file applications extract internal libraries before Python executes, so the custom splash screen starts *after* that brief initial extraction.

**Important:** The ZIP includes the Python source and the Windows EXE builder, **not a precompiled Windows EXE**. This deliverable was generated in a Linux environment that cannot compile or test the actual Windows build. The 19 automated core tests pass, but test the appearance, startup and Windows packaging on a Windows machine before releasing the app publicly.

## Files, data and interface

- **Native `.luma` files**: atomic save, recovery backup, and file association on Windows. Existing LumaGrid 1.0/LunaGrid 1.1 `.luma` files remain readable.
- **Excel**: import `.xlsx`/`.xlsm`, export `.xlsx`. **CSV**: import `.csv`/`.tsv`, export `.csv`.
- **Sheets**: multi-sheet editing, copy/paste, drag/drop opening, sort, filter, search/replace, formatting, resizing, and undo/redo.
- **Insights**: instant statistics, bar/line/area/pie chart previews (export charts to PNG), and grouped summary sheets. Calculated outputs are saved as ordinary values, not live formulas.
- **Light and dark modes**: light by default; change with the top **Dark mode** button. The selected theme is remembered.
- **Private/offline**: no accounts, telemetry or server connections are part of this application.

### Practical notes

**LunaGrid isn't yet a full Excel replacement.** No Excel-formula engine, VBA/macros, pivot tables, built-in team collaboration, data validation rules, or full Excel styling fidelity. Excel files with advanced features must be checked carefully after importing/exporting; macros are not executed or retained. Large workbooks may slow down.

The native `.luma` file format is a ZIP containing JSON data. It is not password protected or encrypted. The data engine is limited to 200,000 rows, 500 columns, and 100 worksheets.

## Testing and troubleshooting

On a computer with dependencies installed:

```bash
python -m pytest -q tests
```

From source, run `python main.py`. When packaged, the app runs without a terminal. If it closes unexpectedly, check `%LOCALAPPDATA%\LunaGrid\error.log`. If you move `LunaGrid.exe` after registering `.luma` file associations, select **More → Associate .luma files** again. Windows might also require confirming the default app in Settings.

## Source files

| File | Purpose |
|---|---|
| `main.py` | GUI launcher, console-free logging, splash timing and maximized launch |
| `splash.py` | Built-in branded startup splash drawn with Qt |
| `ui.py` | Spreadsheet interface, themes, toolbar and click-driven tools |
| `core.py` | Document engine, .luma files, Excel/CSV import/export and transformations |
| `assets/lunagrid.ico` / `assets/lunagrid-icon.png` | Icon assets bundled into the EXE |
| `build_windows.bat` | One-click single-EXE Windows builder |
| `example.luma` | Example workbook |
| `tests/` | Automated engine regression tests |
