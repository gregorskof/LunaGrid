"""Zovanion LunaGrid document model and robust import/export. Pure Python; no GUI dependency."""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import tempfile
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from openpyxl import Workbook as ExcelWorkbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

APP_NAME = "Zovanion LunaGrid"
# Import workbooks created with the original LumaGrid preview build.
LEGACY_APP_NAMES = {"LumaGrid", "LunaGrid", APP_NAME}
NATIVE_EXTENSION = ".luma"
FORMAT_VERSION = 1
MAX_ROWS = 200_000
MAX_COLS = 500
MAX_NATIVE_JSON = 80 * 1024 * 1024
MAX_SHEETS = 100


def key(row: int, col: int) -> str:
    return f"{row},{col}"


def split_key(value: str) -> tuple[int, int]:
    row, col = value.split(",")
    return int(row), int(col)


def normalize_value(value: Any) -> Any:
    if value is None or value == "":
        return None
    if isinstance(value, (date, datetime)):
        return value.isoformat(sep=" ") if isinstance(value, datetime) else value.isoformat()
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        return value
    return str(value)[:32_767]


def parse_input(value: Any) -> Any:
    if not isinstance(value, str):
        return normalize_value(value)
    if not value:
        return None
    stripped = value.strip()
    if re.fullmatch(r"[+-]?(?:0|[1-9]\d{0,17})", stripped):
        try:
            return int(stripped)
        except (OverflowError, ValueError):
            pass
    if re.fullmatch(r"[+-]?(?:\d+\.\d*|\.\d+)(?:[Ee][+-]?\d+)?", stripped) or re.fullmatch(r"[+-]?\d+[Ee][+-]?\d+", stripped):
        try:
            result = float(stripped)
            if math.isfinite(result):
                return result
        except ValueError:
            pass
    return value[:32_767]


def column_label(index: int) -> str:
    text = ""
    index += 1
    while index:
        index, digit = divmod(index - 1, 26)
        text = chr(65 + digit) + text
    return text


def number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, str):
        try:
            v = float(value.strip().replace(" ", "").replace(",", ""))
            return v if math.isfinite(v) else None
        except (ValueError, OverflowError):
            pass
    return None


def statistics(values: list[Any]) -> dict[str, Any]:
    vals = [n for v in values if (n := number(v)) is not None]
    nonblank = sum(v is not None and v != "" for v in values)
    return {
        "count": len(vals), "nonblank": nonblank,
        "sum": sum(vals), "average": sum(vals) / len(vals) if vals else None,
        "minimum": min(vals) if vals else None,
        "maximum": max(vals) if vals else None,
        "unique": len(set(str(v) for v in values if v is not None and v != "")),
    }


@dataclass
class Sheet:
    name: str = "Sheet 1"
    rows: int = 200
    cols: int = 26
    cells: dict[str, Any] = field(default_factory=dict)
    styles: dict[str, dict[str, Any]] = field(default_factory=dict)
    widths: dict[str, int] = field(default_factory=dict)
    banded: bool = True

    def get(self, row: int, col: int) -> Any:
        return self.cells.get(key(row, col))

    def put(self, row: int, col: int, value: Any) -> None:
        if not (0 <= row < MAX_ROWS and 0 <= col < MAX_COLS):
            raise ValueError("Cell outside supported sheet size")
        value = normalize_value(value)
        self.ensure(row + 1, col + 1)
        if value is None:
            self.cells.pop(key(row, col), None)
        else:
            self.cells[key(row, col)] = value

    def ensure(self, rows: int, cols: int) -> None:
        if rows > MAX_ROWS or cols > MAX_COLS:
            raise ValueError(f"Sheet limit: {MAX_ROWS:,} rows and {MAX_COLS} columns")
        self.rows = max(self.rows, rows)
        self.cols = max(self.cols, cols)

    def style(self, row: int, col: int) -> dict[str, Any]:
        return self.styles.get(key(row, col), {})

    def set_style(self, row: int, col: int, changes: dict[str, Any]) -> None:
        k = key(row, col)
        current = dict(self.styles.get(k, {}))
        current.update(changes)
        if current:
            self.styles[k] = current
        else:
            self.styles.pop(k, None)

    def snapshot(self) -> dict[str, Any]:
        return {
            "name": self.name, "rows": self.rows, "cols": self.cols,
            "cells": dict(self.cells),
            "styles": {k: dict(v) for k, v in self.styles.items()},
            "widths": dict(self.widths), "banded": self.banded,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Sheet:
        rows, cols = int(data.get("rows", 200)), int(data.get("cols", 26))
        if not 1 <= rows <= MAX_ROWS or not 1 <= cols <= MAX_COLS:
            raise ValueError("Invalid sheet dimensions")
        name = str(data.get("name", "Sheet"))[:100]
        sheet = cls(name=name, rows=rows, cols=cols, banded=bool(data.get("banded", True)))
        raw = data.get("cells", {})
        if not isinstance(raw, dict) or len(raw) > 3_000_000:
            raise ValueError("Invalid cell data")
        for k, v in raw.items():
            r, c = split_key(k)
            if not 0 <= r < rows or not 0 <= c < cols:
                raise ValueError("Cell position invalid")
            val = normalize_value(v)
            if val is not None:
                sheet.cells[k] = val
        raw_style = data.get("styles", {})
        if not isinstance(raw_style, dict):
            raise ValueError("Invalid styles")
        for k, v in raw_style.items():
            r, c = split_key(k)
            if not 0 <= r < rows or not 0 <= c < cols or not isinstance(v, dict):
                raise ValueError("Invalid cell style")
            sheet.styles[k] = {name: value for name, value in v.items() if name in {"bold", "fill", "text", "align", "format"}}
        raw_widths = data.get("widths", {})
        if isinstance(raw_widths, dict):
            sheet.widths = {str(int(k)): max(45, min(600, int(v))) for k, v in raw_widths.items() if 0 <= int(k) < cols}
        return sheet

    def restore(self, data: dict[str, Any]) -> None:
        fresh = Sheet.from_dict(data)
        self.__dict__.update(fresh.__dict__)

    def _shift(self, axis: int, start: int, count: int, deleting: bool) -> None:
        # Apply the same permutation to values and their visual formatting.
        last = self.rows if axis == 0 else self.cols
        if deleting:
            count = min(count, last - start)
            if count <= 0 or last - count < 1:
                raise ValueError("Cannot delete all rows or columns")
        else:
            if last + count > (MAX_ROWS if axis == 0 else MAX_COLS):
                raise ValueError("Maximum sheet size reached")
        def move(mapping: dict[str, Any]) -> dict[str, Any]:
            dest = {}
            for position, value in mapping.items():
                r, c = split_key(position)
                pos = [r, c]
                n = pos[axis]
                if deleting and start <= n < start + count:
                    continue
                if n >= start + (count if deleting else 0):
                    pos[axis] = n - count if deleting else n + count
                dest[key(*pos)] = value
            return dest
        self.cells = move(self.cells)
        self.styles = move(self.styles)
        if axis == 1:
            shifted = {}
            for k, v in self.widths.items():
                n = int(k)
                if deleting and start <= n < start + count:
                    continue
                if n >= start + (count if deleting else 0):
                    n = n - count if deleting else n + count
                shifted[str(n)] = v
            self.widths = shifted
        if axis == 0:
            self.rows += -count if deleting else count
        else:
            self.cols += -count if deleting else count

    def insert_rows(self, at: int, count: int = 1) -> None:
        if count < 1 or not 0 <= at <= self.rows:
            raise ValueError("Invalid insert row")
        self._shift(0, at, count, False)

    def delete_rows(self, at: int, count: int = 1) -> None:
        if not 0 <= at < self.rows:
            raise ValueError("Invalid delete row")
        self._shift(0, at, count, True)

    def insert_cols(self, at: int, count: int = 1) -> None:
        if count < 1 or not 0 <= at <= self.cols:
            raise ValueError("Invalid insert column")
        self._shift(1, at, count, False)

    def delete_cols(self, at: int, count: int = 1) -> None:
        if not 0 <= at < self.cols:
            raise ValueError("Invalid delete column")
        self._shift(1, at, count, True)

    def sort_by(self, col: int, reverse: bool = False, header: bool = True) -> None:
        # Keep each complete row together, including its cell styles.
        start = 1 if header else 0
        indexed = list(range(start, self.rows))
        def sort_key(r: int):
            v = self.get(r, col)
            n = number(v)
            return (v is None, 0 if n is not None else 1, n if n is not None else str(v or "").casefold())
        # Reversed sorts must still leave blank rows at the bottom.
        indexed.sort(key=lambda r: sort_key(r)[1:], reverse=reverse)
        indexed.sort(key=lambda r: self.get(r, col) is None)
        mapping = {old: new for new, old in enumerate(indexed, start)}
        for field_name in ("cells", "styles"):
            field_data = getattr(self, field_name)
            new_data = {}
            for k, v in field_data.items():
                r, c = split_key(k)
                new_data[key(mapping.get(r, r), c)] = v
            setattr(self, field_name, new_data)

    def remove_duplicates(self, has_header: bool = True) -> int:
        start = 1 if has_header else 0
        rows = defaultdict(dict)
        for k, v in self.cells.items():
            r, c = split_key(k)
            rows[r][c] = v
        seen = set()
        remove = []
        for r in range(start, self.rows):
            signature = tuple((c, str(v)) for c, v in sorted(rows[r].items()))
            if not signature:
                continue
            if signature in seen:
                remove.append(r)
            seen.add(signature)
        if not remove:
            return 0
        removed = set(remove)
        prev = [0] * self.rows
        n = 0
        for r in range(self.rows):
            prev[r] = n
            if r in removed:
                n += 1
        for attr in ("cells", "styles"):
            result = {}
            for k, v in getattr(self, attr).items():
                r, c = split_key(k)
                if r not in removed:
                    result[key(r - prev[r], c)] = v
            setattr(self, attr, result)
        self.rows -= len(remove)
        return len(remove)

    def group_summary(self, category_col: int, value_col: int, operation: str = "sum") -> Sheet:
        groups: dict[str, list[float]] = defaultdict(list)
        counts: dict[str, int] = defaultdict(int)
        for r in range(1, self.rows):
            category = self.get(r, category_col)
            if category is None:
                continue
            label = str(category)
            counts[label] += 1
            n = number(self.get(r, value_col))
            if n is not None:
                groups[label].append(n)
        output = Sheet(name="Summary", rows=max(40, len(counts) + 2), cols=4)
        output.put(0, 0, str(self.get(0, category_col) or "Category"))
        output.put(0, 1, operation.title())
        for row, group in enumerate(sorted(counts), 1):
            nums = groups[group]
            if operation == "count":
                result = counts[group]
            elif operation == "average":
                result = sum(nums) / len(nums) if nums else 0
            elif operation == "min":
                result = min(nums) if nums else 0
            elif operation == "max":
                result = max(nums) if nums else 0
            else:
                result = sum(nums)
            output.put(row, 0, group)
            output.put(row, 1, result)
        for c in range(2):
            output.set_style(0, c, {"bold": True, "fill": "#34466a", "text": "#ffffff"})
        return output


def fill_number_series(sheet: Sheet, row: int, col: int, count: int, start: float, step: float) -> None:
    """Write an arithmetic series without formulas (the result is editable values)."""
    if not (0 <= row < MAX_ROWS and 0 <= col < MAX_COLS and 1 <= count <= 10_000
            and row + count <= MAX_ROWS and math.isfinite(start) and math.isfinite(step)):
        raise ValueError("Invalid starting cell or series size")
    sheet.ensure(row + count, col + 1)
    for index in range(count):
        value = start + step * index
        if not math.isfinite(value):
            raise ValueError("Number series contains an invalid value")
        sheet.put(row + index, col, int(value) if value.is_integer() else value)


def split_text_column(sheet: Sheet, col: int, separator: str, max_parts: int = 8) -> int:
    """Split a column into newly inserted adjacent columns without overwriting data.

    Returns count of *additional* columns. Only string cells are split.
    """
    if not 0 <= col < sheet.cols or not separator or len(separator) > 10 or not 2 <= max_parts <= 16:
        raise ValueError("Choose a valid column and separator")
    original = []
    most = 1
    for address, value in list(sheet.cells.items()):
        row, column = split_key(address)
        if column == col and isinstance(value, str) and separator in value:
            chunks = value.split(separator, max_parts - 1)
            original.append((row, chunks))
            most = max(most, len(chunks))
    if most <= 1:
        return 0
    sheet.insert_cols(col + 1, most - 1)
    for row, chunks in original:
        for offset, item in enumerate(chunks):
            sheet.put(row, col + offset, item.strip() or None)
    return most - 1


def transform_text_cells(sheet: Sheet, coordinates: list[tuple[int, int]], operation: str) -> int:
    functions = {"UPPERCASE": str.upper, "lowercase": str.lower, "Title Case": str.title,
                 "Trim spaces": str.strip}
    if operation not in functions:
        raise ValueError("Unknown text transformation")
    if len(coordinates) > 100_000:
        raise ValueError("Select fewer cells")
    count = 0
    for row, col in coordinates:
        value = sheet.get(row, col)
        if isinstance(value, str):
            updated = functions[operation](value)
            if updated != value:
                sheet.put(row, col, updated)
                count += 1
    return count


def highlight_duplicate_values(sheet: Sheet, col: int, color: str = "#FFF0C2") -> int:
    """Apply static highlights to repeated nonempty values below the header row."""
    if not 0 <= col < sheet.cols:
        raise ValueError("Invalid column")
    groups: dict[str, list[int]] = defaultdict(list)
    for address, value in sheet.cells.items():
        row, column = split_key(address)
        if row > 0 and column == col and value is not None and str(value).strip():
            groups[str(value).casefold().strip()].append(row)
    repeated = [row for positions in groups.values() if len(positions) > 1 for row in positions]
    for row in repeated:
        sheet.set_style(row, col, {"fill": color})
    return len(repeated)


def format_header_row(sheet: Sheet) -> int:
    """Apply a readable table header to occupied cells in row 1."""
    headings = sorted(c for address in sheet.cells for r, c in [split_key(address)] if r == 0)
    if not headings:
        return 0
    for col in headings:
        sheet.set_style(0, col, {"bold": True, "fill": "#2F67D8", "text": "#FFFFFF"})
    sheet.banded = True
    return len(headings)


@dataclass
class Book:
    sheets: list[Sheet] = field(default_factory=lambda: [Sheet()])
    active: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {"app": APP_NAME, "version": FORMAT_VERSION, "active": self.active,
                "sheets": [s.snapshot() for s in self.sheets]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Book:
        if data.get("app") not in LEGACY_APP_NAMES:
            raise ValueError("Not a compatible LunaGrid workbook")
        if data.get("version") != FORMAT_VERSION:
            raise ValueError("Unsupported workbook version")
        raw_sheets = data.get("sheets")
        if not isinstance(raw_sheets, list) or not 1 <= len(raw_sheets) <= MAX_SHEETS:
            raise ValueError("Invalid sheets")
        sheets = [Sheet.from_dict(x) for x in raw_sheets]
        active = int(data.get("active", 0))
        return cls(sheets, min(max(active, 0), len(sheets) - 1))

    def unique_name(self, desired: str, exclude: Sheet | None = None) -> str:
        desired = desired.strip() or "Sheet"
        existing = {s.name.casefold() for s in self.sheets if s is not exclude}
        if desired.casefold() not in existing:
            return desired
        n = 2
        while f"{desired} ({n})".casefold() in existing:
            n += 1
        return f"{desired} ({n})"


def _atomic_write(path: str, writer) -> None:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{destination.stem}-", suffix=destination.suffix, dir=destination.parent)
    os.close(fd)
    try:
        writer(temporary)
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def save_native(book: Book, path: str) -> None:
    raw = json.dumps(book.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    if len(raw) > MAX_NATIVE_JSON:
        raise ValueError("Workbook is too large to save in this format")
    def write(tmp):
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            archive.writestr("workbook.json", raw)
    _atomic_write(path, write)


def load_native(path: str) -> Book:
    with zipfile.ZipFile(path, "r") as archive:
        entries = archive.infolist()
        if len(entries) != 1 or entries[0].filename != "workbook.json" or entries[0].file_size > MAX_NATIVE_JSON:
            raise ValueError("Invalid or oversized LunaGrid document")
        raw = archive.read("workbook.json")
    return Book.from_dict(json.loads(raw.decode("utf-8")))


def load_xlsx(path: str) -> Book:
    # Normal mode preserves Excel styling; data_only avoids evaluating imported formulas.
    excel = load_workbook(path, data_only=True, read_only=False, keep_links=False)
    try:
        result = []
        if len(excel.worksheets) > MAX_SHEETS:
            raise ValueError("Workbook has more worksheets than supported")
        for ws in excel.worksheets:
            rows, cols = ws.max_row or 1, ws.max_column or 1
            if rows > MAX_ROWS or cols > MAX_COLS:
                raise ValueError(f"'{ws.title}' exceeds supported dimensions")
            sheet = Sheet(name=ws.title, rows=max(200, rows), cols=max(26, cols))
            for row in ws.iter_rows():
                for cell in row:
                    if cell.value is not None:
                        sheet.put(cell.row - 1, cell.column - 1, cell.value)
                    if not cell.has_style:
                        continue
                    styling = {}
                    if cell.font.bold:
                        styling["bold"] = True
                    if cell.fill.patternType == "solid" and cell.fill.fgColor.type == "rgb":
                        rgb = cell.fill.fgColor.rgb
                        if isinstance(rgb, str) and len(rgb) >= 6:
                            styling["fill"] = "#" + rgb[-6:]
                    if cell.font.color is not None and cell.font.color.type == "rgb":
                        rgb = cell.font.color.rgb
                        if isinstance(rgb, str) and len(rgb) >= 6:
                            # Imported black-on-white would be unreadable on a dark grid.
                            color = rgb[-6:]
                            if styling.get("fill") or int(color, 16) > 0x777777:
                                styling["text"] = "#" + color
                    if cell.alignment.horizontal in {"left", "center", "right"}:
                        styling["align"] = cell.alignment.horizontal
                    fmt = cell.number_format
                    if isinstance(cell.value, (date, datetime)) or "yy" in fmt.lower() or "dd" in fmt.lower():
                        styling["format"] = "date"
                    elif "%" in fmt:
                        styling["format"] = "percent"
                    elif "€" in fmt or "$" in fmt or "£" in fmt:
                        styling["format"] = "currency"
                    elif fmt in {"#,##0.00", "0.00"}:
                        styling["format"] = "number"
                    elif fmt in {"#,##0", "0"}:
                        styling["format"] = "integer"
                    if styling:
                        sheet.set_style(cell.row - 1, cell.column - 1, styling)
            for name, dimension in ws.column_dimensions.items():
                from openpyxl.utils import column_index_from_string
                try:
                    idx = column_index_from_string(name) - 1
                    if idx < sheet.cols and dimension.width:
                        sheet.widths[str(idx)] = max(45, min(600, int(dimension.width * 8)))
                except ValueError:
                    pass
            result.append(sheet)
        return Book(result or [Sheet()])
    finally:
        excel.close()


def _excel_safe_name(name: str, used: set[str]) -> str:
    name = re.sub(r"[\\/*?:\[\]]", "_", name).strip("' ")[:31] or "Sheet"
    base = name
    i = 2
    while name.casefold() in used:
        suffix = f" ({i})"
        name = base[:31 - len(suffix)] + suffix
        i += 1
    used.add(name.casefold())
    return name


def export_xlsx(book: Book, path: str) -> None:
    excel = ExcelWorkbook()
    excel.remove(excel.active)
    names: set[str] = set()
    for sheet in book.sheets:
        ws = excel.create_sheet(_excel_safe_name(sheet.name, names))
        for address, value in sheet.cells.items():
            r, c = split_key(address)
            output = ws.cell(row=r + 1, column=c + 1, value=value)
            if isinstance(value, str) and value.startswith("="):
                output.data_type = "s"  # user-entered text is NEVER executed as an Excel formula
        for address, style in sheet.styles.items():
            r, c = split_key(address)
            output = ws.cell(row=r + 1, column=c + 1)
            bold = bool(style.get("bold", False))
            text_color = str(style.get("text", "#24324C")).lstrip("#")
            output.font = Font(name="Aptos", bold=bold, color=text_color if re.fullmatch(r"[A-Fa-f0-9]{6}", text_color) else "24324C")
            fill = style.get("fill")
            if isinstance(fill, str) and re.fullmatch(r"#[A-Fa-f0-9]{6}", fill):
                output.fill = PatternFill("solid", fgColor=fill.lstrip("#"))
            output.alignment = Alignment(horizontal=style.get("align", "left"))
            formats = {"number": "#,##0.00", "integer": "#,##0", "currency": '"€"#,##0.00',
                       "percent": "0.00%", "date": "yyyy-mm-dd"}
            output.number_format = formats.get(style.get("format"), "General")
        for col, width in sheet.widths.items():
            ws.column_dimensions[get_column_letter(int(col) + 1)].width = max(8, min(70, width / 8))
        ws.sheet_view.showGridLines = True
    excel.active = book.active
    _atomic_write(path, excel.save)


def import_csv(path: str) -> Book:
    with open(path, "r", newline="", encoding="utf-8-sig") as handle:
        sample = handle.read(16_384)
        handle.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        sheet = Sheet(name=Path(path).stem[:60] or "Imported")
        for r, row in enumerate(csv.reader(handle, dialect)):
            if r >= MAX_ROWS or len(row) > MAX_COLS:
                raise ValueError("CSV exceeds supported sheet size")
            if row:
                sheet.ensure(r + 1, len(row))
            for c, value in enumerate(row):
                if value != "":
                    sheet.put(r, c, parse_input(value))
    return Book([sheet])


def export_csv(sheet: Sheet, path: str) -> None:
    # Protect users opening the exported CSV in Excel against spreadsheet formula injection.
    def safe(value):
        if value is None:
            return ""
        if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
            return "'" + value
        return value
    occupied = [split_key(k) for k in sheet.cells]
    max_row = max((r for r, _ in occupied), default=-1)
    max_col = max((c for _, c in occupied), default=-1)
    def write(tmp):
        with open(tmp, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            for r in range(max_row + 1):
                writer.writerow([safe(sheet.get(r, c)) for c in range(max_col + 1)])
    _atomic_write(path, write)


def load_file(path: str) -> Book:
    suffix = Path(path).suffix.casefold()
    if suffix == ".luma":
        return load_native(path)
    if suffix in {".xlsx", ".xlsm"}:
        return load_xlsx(path)
    if suffix in {".csv", ".tsv"}:
        return import_csv(path)
    raise ValueError("Unsupported file type. Use .luma, .xlsx, .xlsm or .csv")


# v1.3 click-first data tools. These operations do not evaluate spreadsheet formulas.
def fill_date_series(sheet: Sheet, row: int, col: int, count: int, start: date, step_days: int = 1) -> None:
    if not isinstance(start, date) or isinstance(start, datetime) or not 1 <= count <= 10_000 or not -3650 <= step_days <= 3650 or row < 0 or row + count > MAX_ROWS or not 0 <= col < MAX_COLS:
        raise ValueError("Invalid date series settings")
    dates = []
    for i in range(count):
        try:
            dates.append((start + timedelta(days=i * step_days)).isoformat())
        except OverflowError as e:
            raise ValueError("Date series goes outside supported dates") from e
    for i, day in enumerate(dates):
        sheet.put(row + i, col, day)


def combine_columns(sheet: Sheet, first: int, second: int, separator: str = " ") -> int:
    if not (0 <= first < sheet.cols and 0 <= second < sheet.cols and first != second and len(separator) <= 20):
        raise ValueError("Choose two different columns")
    # Inserting a new column after both inputs protects existing adjacent data.
    dest = max(first, second) + 1
    if sheet.cols >= MAX_COLS:
        raise ValueError("Maximum number of columns reached")
    entries = []
    for r in range(sheet.rows):
        a, b = sheet.get(r, first), sheet.get(r, second)
        parts = [str(v).strip() for v in (a, b) if v is not None and str(v).strip()]
        if parts:
            entries.append((r, separator.join(parts)))
    sheet.insert_cols(dest)
    for r, value in entries:
        sheet.put(r, dest, value)
    sheet.put(0, dest, "Combined" if sheet.get(0, dest) is None else sheet.get(0, dest))
    return dest


def _used_row_range(sheet: Sheet) -> tuple[int, int]:
    rows = [split_key(a)[0] for a in sheet.cells]
    return (min(rows), max(rows)) if rows else (0, 0)


def remove_empty_rows(sheet: Sheet) -> int:
    """Remove completely empty rows *between* the header and last occupied row.
    Do not remove the blank worksheet canvas after the data.
    """
    if not sheet.cells:
        return 0
    last = max(split_key(k)[0] for k in sheet.cells)
    occupied = {split_key(k)[0] for k in sheet.cells}
    missing = set(range(1, last + 1)) - occupied
    if not missing:
        return 0
    from bisect import bisect_left
    missing_ordered = sorted(missing)
    for attr in ("cells", "styles"):
        data = getattr(sheet, attr)
        result = {}
        for address, value in data.items():
            r, c = split_key(address)
            if r not in missing:
                result[key(r - bisect_left(missing_ordered, r), c)] = value
        setattr(sheet, attr, result)
    sheet.rows = max(1, sheet.rows - len(missing))
    return len(missing)


def remove_empty_columns(sheet: Sheet) -> int:
    """Remove unused data columns between A and the last populated column."""
    if not sheet.cells:
        return 0
    last = max(split_key(k)[1] for k in sheet.cells)
    occupied = {split_key(k)[1] for k in sheet.cells}
    missing = set(range(0, last + 1)) - occupied
    if not missing:
        return 0
    from bisect import bisect_left
    missing_ordered = sorted(missing)
    for attr in ("cells", "styles"):
        result = {}
        for address, value in getattr(sheet, attr).items():
            r, c = split_key(address)
            if c not in missing:
                result[key(r, c - bisect_left(missing_ordered, c))] = value
        setattr(sheet, attr, result)
    sheet.widths = {str(c - bisect_left(missing_ordered, c)): v
                    for text, v in sheet.widths.items() for c in [int(text)] if c not in missing}
    sheet.cols = max(1, sheet.cols - len(missing))
    return len(missing)


def column_profile_sheet(sheet: Sheet) -> Sheet:
    """Compact quality report for all occupied columns; starts after the header row."""
    columns = sorted({split_key(k)[1] for k in sheet.cells})
    if not columns:
        raise ValueError("Add some data before generating a profile")
    output = Sheet(name="Data profile", rows=max(40, len(columns) + 2), cols=9)
    heads = ["Column", "Header", "Filled", "Blank", "Unique", "Numeric", "Sum", "Average", "Range"]
    for c, v in enumerate(heads):
        output.put(0, c, v)
    last = max(split_key(k)[0] for k in sheet.cells)
    for i, col in enumerate(columns, 1):
        values = [value for address, value in sheet.cells.items()
                  if (pos := split_key(address))[1] == col and pos[0] >= 1]
        stats = statistics(values)
        numeric = [number(v) for v in values if number(v) is not None]
        row = [column_label(col), str(sheet.get(0, col) or ""), stats["nonblank"],
               max(0, last - stats["nonblank"]), stats["unique"], stats["count"],
               stats["sum"], stats["average"],
               f"{min(numeric):g} – {max(numeric):g}" if numeric else "—"]
        for c, v in enumerate(row):
            if v is not None:
                output.put(i, c, v)
    format_header_row(output)
    return output


def frequency_table_sheet(sheet: Sheet, column: int) -> Sheet:
    if not 0 <= column < sheet.cols:
        raise ValueError("Invalid column")
    frequencies: dict[str, int] = defaultdict(int)
    for address, value in sheet.cells.items():
        r, c = split_key(address)
        if r > 0 and c == column and value is not None and str(value).strip():
            frequencies[str(value).strip()] += 1
    if not frequencies:
        raise ValueError("This column has no data below its header")
    if len(frequencies) > 20_000:
        raise ValueError("Too many unique categories for a single report")
    output = Sheet(name="Frequency", rows=max(40, len(frequencies) + 2), cols=3)
    output.put(0, 0, str(sheet.get(0, column) or column_label(column)))
    output.put(0, 1, "Count")
    output.put(0, 2, "Share")
    total = sum(frequencies.values())
    for r, (label, count) in enumerate(sorted(frequencies.items(), key=lambda item: (-item[1], item[0].casefold())), 1):
        output.put(r, 0, label)
        output.put(r, 1, count)
        output.put(r, 2, round(100 * count / total, 2))
    output.put(0, 2, "Share (%)")
    format_header_row(output)
    return output


def unique_values_sheet(sheet: Sheet, column: int) -> Sheet:
    if not 0 <= column < sheet.cols:
        raise ValueError("Invalid column")
    values = []
    seen = set()
    for r in range(1, sheet.rows):
        value = sheet.get(r, column)
        if value is not None and str(value).strip():
            marker = str(value).strip().casefold()
            if marker not in seen:
                seen.add(marker)
                values.append(value)
    if not values:
        raise ValueError("This column has no values")
    output = Sheet(name="Unique values", rows=max(40, len(values) + 1), cols=2)
    output.put(0, 0, str(sheet.get(0, column) or column_label(column)))
    for r, value in enumerate(values, 1):
        output.put(r, 0, value)
    format_header_row(output)
    return output


def transpose_selection(sheet: Sheet, top: int, left: int, bottom: int, right: int) -> Sheet:
    height, width = bottom - top + 1, right - left + 1
    if min(top, left) < 0 or height < 1 or width < 1 or height > MAX_COLS or width > MAX_ROWS:
        raise ValueError("Selected range is too large to transpose")
    if height * width > 100_000:
        raise ValueError("Select no more than 100,000 cells")
    output = Sheet(name="Transposed", rows=max(40, width), cols=max(26, height))
    for r in range(height):
        for c in range(width):
            value = sheet.get(top + r, left + c)
            if value is not None:
                output.put(c, r, value)
    return output


def normalize_whitespace(sheet: Sheet, positions: list[tuple[int, int]]) -> int:
    if len(positions) > 100_000:
        raise ValueError("Select fewer cells")
    updated = 0
    for r, c in positions:
        old = sheet.get(r, c)
        if isinstance(old, str):
            new = " ".join(old.split())
            if new != old:
                sheet.put(r, c, new)
                updated += 1
    return updated


def convert_numeric_text(sheet: Sheet, positions: list[tuple[int, int]]) -> int:
    if len(positions) > 100_000:
        raise ValueError("Select fewer cells")
    updated = 0
    for r, c in positions:
        old = sheet.get(r, c)
        if isinstance(old, str):
            new = parse_input(old.strip())
            if isinstance(new, (float, int)) and not isinstance(new, bool):
                sheet.put(r, c, new)
                updated += 1
    return updated


def highlight_by_rule(sheet: Sheet, column: int, operator: str, threshold: float, color: str = "#FDECC8") -> int:
    if not 0 <= column < sheet.cols or operator not in ("Above", "Below", "Equal") or not math.isfinite(threshold):
        raise ValueError("Choose a valid numeric comparison")
    matches = []
    for address, value in sheet.cells.items():
        r, c = split_key(address)
        if r > 0 and c == column:
            n = number(value)
            if n is not None and ((operator == "Above" and n > threshold) or
                                  (operator == "Below" and n < threshold) or
                                  (operator == "Equal" and n == threshold)):
                matches.append(r)
    for r in matches:
        sheet.set_style(r, column, {"fill": color})
    return len(matches)


def highlight_blanks(sheet: Sheet, column: int) -> int:
    if not 0 <= column < sheet.cols:
        raise ValueError("Invalid column")
    # Only check the occupied portion, never the whole empty 200-row canvas.
    last = max((split_key(k)[0] for k in sheet.cells), default=0)
    if last > 100_000:
        raise ValueError("Select a smaller dataset")
    blanks = [r for r in range(1, last + 1) if sheet.get(r, column) is None]
    for r in blanks:
        sheet.set_style(r, column, {"fill": "#FEE2E2"})
    return len(blanks)


def highlight_outliers(sheet: Sheet, column: int, standard_deviations: float = 2.0) -> int:
    if not 0 <= column < sheet.cols or not 1 <= standard_deviations <= 5:
        raise ValueError("Invalid column or sensitivity")
    records = [(r, number(v)) for address, v in sheet.cells.items()
               for r, c in [split_key(address)] if r > 0 and c == column]
    records = [(r, v) for r, v in records if v is not None]
    if len(records) < 3:
        raise ValueError("At least three numeric values are required")
    avg = sum(v for _, v in records) / len(records)
    variance = sum((v - avg) ** 2 for _, v in records) / len(records)
    dev = math.sqrt(variance)
    if not dev:
        return 0
    match = [r for r, v in records if abs(v - avg) > standard_deviations * dev]
    for r in match:
        sheet.set_style(r, column, {"fill": "#FBE2A6"})
    return len(match)
