"""LunaGrid v1.3 data tools regression tests (no GUI dependency)."""
import ast
from datetime import date
from pathlib import Path

import pytest
from core import (
    Sheet, Book, fill_date_series, combine_columns, remove_empty_rows,
    remove_empty_columns, column_profile_sheet, frequency_table_sheet,
    unique_values_sheet, transpose_selection, normalize_whitespace,
    convert_numeric_text, highlight_by_rule, highlight_blanks,
    highlight_outliers, save_native, load_native,
)


def sample():
    s = Sheet(rows=25, cols=6)
    for c, title in enumerate(['Name', 'Team', 'Sales', 'Notes']):
        s.put(0, c, title)
    s.put(1, 0, 'Ana'); s.put(1, 1, 'Blue'); s.put(1, 2, 10)
    s.put(2, 0, 'Bob'); s.put(2, 1, 'Blue'); s.put(2, 2, 20)
    s.put(3, 0, 'Mira'); s.put(3, 1, 'Red'); s.put(3, 2, 30)
    return s


def test_date_series_calendar_and_bounds():
    s = Sheet()
    fill_date_series(s, 1, 0, 3, date(2028, 2, 28), 1)
    assert [s.get(r, 0) for r in range(1,4)] == ['2028-02-28', '2028-02-29', '2028-03-01']
    with pytest.raises(ValueError):
        fill_date_series(s, 199999, 0, 4, date.today(), 1)
    with pytest.raises(ValueError):
        fill_date_series(s, 0, 0, 20, date(9999, 12, 28), 100)


def test_combine_columns_preserves_neighboring_data_and_formatting():
    s = sample(); s.put(1,3,'DO NOT MOVE OVER ME'); s.set_style(1,3,{'bold':True})
    destination = combine_columns(s, 0, 1, ' / ')
    assert destination == 2
    assert s.get(1,2) == 'Ana / Blue'
    assert s.get(1,3) == 10
    assert s.get(1,4) == 'DO NOT MOVE OVER ME'
    assert s.style(1,4)['bold'] is True
    with pytest.raises(ValueError):
        combine_columns(s, 0, 0)


def test_remove_empty_rows_only_inside_data_preserves_styles():
    s = Sheet(rows=20)
    s.put(0,0,'Title'); s.put(1,0,'A'); s.put(4,0,'B')
    s.set_style(4,0,{'bold':True})
    assert remove_empty_rows(s) == 2
    assert s.get(2,0) == 'B'
    assert s.style(2,0)['bold'] is True
    assert s.rows == 18
    assert remove_empty_rows(s) == 0


def test_remove_empty_columns_no_data_loss():
    s = Sheet(rows=12, cols=8)
    s.put(0,0,'A'); s.put(0,3,'D'); s.set_style(0,3,{'bold':True})
    s.widths['3']=178
    assert remove_empty_columns(s) == 2
    assert s.get(0,1) == 'D'
    assert s.style(0,1)['bold']
    assert s.widths['1'] == 178


def test_profile_and_frequency_and_unique():
    s = sample()
    profile = column_profile_sheet(s)
    assert profile.get(0,0) == 'Column'
    assert profile.get(3,1) == 'Sales'
    assert profile.get(3,2) == 3
    assert profile.get(3,6) == 60
    frequency = frequency_table_sheet(s, 1)
    assert frequency.get(1,0) == 'Blue'
    assert frequency.get(1,1) == 2
    assert abs(frequency.get(1,2) - 66.67) < 0.001
    unique = unique_values_sheet(s,1)
    assert unique.get(1,0) == 'Blue'
    assert unique.get(2,0) == 'Red'


def test_transpose_range_non_destructive():
    s = sample()
    t = transpose_selection(s, 0,0,2,2)
    assert t.get(0,0) == 'Name'
    assert t.get(0,1) == 'Ana'
    assert t.get(1,2) == 'Blue'
    assert s.get(2,1) == 'Blue'
    with pytest.raises(ValueError):
        transpose_selection(s,0,0,600,2)


def test_collapse_whitespace_and_convert_numeric_text():
    s = Sheet(); s.put(1,0,'   hello  \n world  '); s.put(2,0,' 27.50 '); s.put(3,0,'00123')
    assert normalize_whitespace(s,[(1,0)]) == 1
    assert s.get(1,0) == 'hello world'
    assert convert_numeric_text(s,[(2,0),(3,0)]) == 1
    assert s.get(2,0) == 27.5
    assert s.get(3,0) == '00123'  # preserve identifiers


def test_numeric_highlights_and_blanks():
    s = sample(); s.put(4,0,'Empty sales')
    assert highlight_by_rule(s,2,'Above',15) == 2
    assert s.style(2,2)['fill'] == '#FDECC8'
    assert highlight_blanks(s,2) == 1
    assert s.style(4,2)['fill'] == '#FEE2E2'
    with pytest.raises(ValueError):
        highlight_by_rule(s,2,'EXEC',1)


def test_outliers_no_false_positive_with_uniform_values():
    s = Sheet(); s.put(0,0,'Numbers')
    for r,v in enumerate([10,10,10,10,10,10,10,10,10,100],1):
        s.put(r,0,v)
    assert highlight_outliers(s,0,2) == 1
    assert s.style(10,0)['fill'] == '#FBE2A6'
    with pytest.raises(ValueError):
        highlight_outliers(Sheet(),0)


def test_native_roundtrip_for_new_features(tmp_path):
    s = sample()
    s2 = frequency_table_sheet(s, 1)
    path = tmp_path/'advanced.luma'
    save_native(Book(sheets=[s,s2]),str(path))
    b = load_native(str(path))
    assert b.sheets[1].get(1,0) == 'Blue'
    assert b.sheets[0].get(1,2) == 10


def test_regression_chart_qt_metric_and_maximized_startup():
    ui = Path(__file__).resolve().parents[1]/'ui.py'
    code = ui.read_text()
    node = ast.parse(code)
    chart = next(x for x in node.body if isinstance(x,ast.ClassDef) and x.name=='ChartDialog')
    for assign in ast.walk(chart):
        if isinstance(assign, (ast.Assign, ast.AnnAssign)):
            targets = assign.targets if isinstance(assign,ast.Assign) else [assign.target]
            assert all(not (isinstance(t,ast.Attribute) and t.attr=='metric' and isinstance(t.value,ast.Name) and t.value.id=='self') for t in targets)
    main = (ui.parent/'main.py').read_text()
    assert 'window.showMaximized()' in main
    assert 'window.showFullScreen()' not in main
